"use client"

import { useState } from "react"
import {
  ArrowUp,
  CheckCircle,
  Download,
  XCircle,
  Minus,
  TrendingUp,
  Activity,
  FileText,
  Presentation,
  FileSpreadsheet,
  Loader2,
  AlertTriangle,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { PDFExporter, type ExportOptions } from "@/lib/pdf-export"
import { PPTExporter, type PPTExportOptions } from "@/lib/ppt-export"
import { useToast } from "@/hooks/use-toast"

// Status Management Constants
const STATUS_TYPES = {
  EXCELLENT: "excellent",
  MODERATE: "moderate",
  CRITICAL: "critical",
} as const

// Enum-Based Status System for Score-Based Calculations
enum StatusLevel {
  EXCELLENT = "excellent",
  MODERATE = "moderate",
  CRITICAL = "critical",
}

// Score ranges configuration
const SCORE_RANGES = [
  { min: 7, max: 10, status: StatusLevel.EXCELLENT },
  { min: 4, max: 6.99, status: StatusLevel.MODERATE },
  { min: 0, max: 3.99, status: StatusLevel.CRITICAL },
] as const

const getStatusFromScoreRange = (score: number): StatusLevel => {
  const range = SCORE_RANGES.find((r) => score >= r.min && score <= r.max)
  return range?.status ?? StatusLevel.CRITICAL
}

const VALIDATION_STATUS_MAP = {
  Yes: STATUS_TYPES.EXCELLENT,
  Neutre: STATUS_TYPES.MODERATE,
  No: STATUS_TYPES.CRITICAL,
} as const

// Centralized status determination function
const getStatusFromValidation = (validationResult: string): string => {
  return VALIDATION_STATUS_MAP[validationResult as keyof typeof VALIDATION_STATUS_MAP] || STATUS_TYPES.CRITICAL
}

export default function SupplierDashboard() {
  const [activeTab, setActiveTab] = useState("profitability")
  const [isExporting, setIsExporting] = useState(false)
  const { toast } = useToast()

  // Financial data structure with dynamic amounts based on codes
  const financialData = [
    { document: "Bilan actif", categorie: "Total", intitule: "Total Actif Immobilisé NET", code: "BJ", amount: "$bj" },
    {
      document: "Bilan actif",
      categorie: "Actif circulant : Créances",
      intitule: "Clients et comptes rattachés",
      code: "BX",
      amount: "$bx",
    },
    {
      document: "Bilan actif",
      categorie: "Actif circulant : Divers",
      intitule: "Valeur mobilières de placement (dont actions propres)",
      code: "CD",
      amount: "$cd",
    },
    {
      document: "Bilan actif",
      categorie: "Actif circulant : Divers",
      intitule: "Disponibilités",
      code: "CF",
      amount: "$cf",
    },
    {
      document: "Bilan actif",
      categorie: "Comptes de régularisation",
      intitule: "Total 3 Bilan actif (NET)",
      code: "CJ",
      amount: "$cj",
    },
    {
      document: "Bilan actif",
      categorie: "Comptes de régularisation",
      intitule: "Total général bilan actif",
      code: "CO",
      amount: "$co",
    },
    {
      document: "Bilan passif",
      categorie: "Capitaux propres",
      intitule: "Total Capitaux propres",
      code: "DL",
      amount: "$dl",
    },
    {
      document: "Bilan passif",
      categorie: "Autres fonds propres",
      intitule: "Total Autres fonds propres",
      code: "DO",
      amount: "$do",
    },
    {
      document: "Bilan passif",
      categorie: "Provisions pour risques et charges",
      intitule: "Total Provisions pour risques et charges",
      code: "DR",
      amount: "$dr",
    },
    {
      document: "Bilan passif",
      categorie: "Dettes",
      intitule: "Emprunts obligataires convertibles",
      code: "DS",
      amount: "$ds",
    },
    {
      document: "Bilan passif",
      categorie: "Dettes",
      intitule: "Autres Emprunts obligataires",
      code: "DT",
      amount: "$dt",
    },
    {
      document: "Bilan passif",
      categorie: "Dettes",
      intitule: "Emprunts et dettes auprès des établissements de crédit",
      code: "DU",
      amount: "$du",
    },
    {
      document: "Bilan passif",
      categorie: "Dettes",
      intitule: "Emprunts et dettes financières (Dont emprunts participatifs)",
      code: "DV",
      amount: "$dv",
    },
    {
      document: "Bilan passif",
      categorie: "Dettes",
      intitule: "Avances et acomptes reçus sur commandes en cours",
      code: "DW",
      amount: "$dw",
    },
    {
      document: "Bilan passif",
      categorie: "Dettes",
      intitule: "Dettes fournisseurs et comptes rattachés",
      code: "DX",
      amount: "$dx",
    },
    {
      document: "Bilan passif",
      categorie: "Dettes",
      intitule: "Dettes fiscales et sociales",
      code: "DY",
      amount: "$dy",
    },
    {
      document: "Bilan passif",
      categorie: "Dettes",
      intitule: "Dettes sur immobilisations et comptes rattachés",
      code: "DZ",
      amount: "$dz",
    },
    { document: "Bilan passif", categorie: "Dettes", intitule: "Autres dettes", code: "EA", amount: "$ea" },
    {
      document: "Bilan passif",
      categorie: "Comptes de régularisation",
      intitule: "Produits constatés d'avance",
      code: "EB",
      amount: "$eb",
    },
    {
      document: "Bilan passif",
      categorie: "Total",
      intitule: "Total Bilan passif hors écart de conversion",
      code: "EC",
      amount: "$ec",
    },
    { document: "Bilan passif", categorie: "Total", intitule: "Total Bilan passif", code: "EE", amount: "$ee" },
    {
      document: "Bilan passif",
      categorie: "Renvois EB",
      intitule: "Dettes et produits constatés d'avance à moins d'un an",
      code: "EG",
      amount: "$eg",
    },
    {
      document: "Bilan passif",
      categorie: "Renvois DU",
      intitule: "Concours bancaires courants, et soldes créditeurs de banques",
      code: "EH",
      amount: "$eh",
    },
    {
      document: "Compte de résultat",
      categorie: "Produits d'exploitation",
      intitule: "Total Ventes de marchandises",
      code: "FC",
      amount: "$fc",
    },
    {
      document: "Compte de résultat",
      categorie: "Produits d'exploitation",
      intitule: "Production vendue de biens",
      code: "FF",
      amount: "$ff",
    },
    {
      document: "Compte de résultat",
      categorie: "Produits d'exploitation",
      intitule: "Production vendue de services",
      code: "FI",
      amount: "$fi",
    },
    {
      document: "Compte de résultat",
      categorie: "Produits d'exploitation",
      intitule: "CA pdts d'exploitation",
      code: "FL",
      amount: "$fl",
    },
    {
      document: "Compte de résultat",
      categorie: "Produits d'exploitation",
      intitule: "Production stockée",
      code: "FM",
      amount: "$fm",
    },
    {
      document: "Compte de résultat",
      categorie: "Produits d'exploitation",
      intitule: "Production immobilisée",
      code: "FN",
      amount: "$fn",
    },
    {
      document: "Compte de résultat",
      categorie: "Produits d'exploitation",
      intitule: "Subventions d'exploitation",
      code: "FO",
      amount: "$fo",
    },
    {
      document: "Compte de résultat",
      categorie: "Produits d'exploitation",
      intitule: "Reprises sur amortissements et provisions, transferts de charges",
      code: "FP",
      amount: "$fp",
    },
    {
      document: "Compte de résultat",
      categorie: "Produits d'exploitation",
      intitule: "Autres produits",
      code: "FQ",
      amount: "$fq",
    },
    {
      document: "Compte de résultat",
      categorie: "Charges d'exploitation",
      intitule: "Achats de marchandises (y compris droit de douane)",
      code: "FS",
      amount: "$fs",
    },
    {
      document: "Compte de résultat",
      categorie: "Charges d'exploitation",
      intitule: "Variation de stock (marchandises)",
      code: "FT",
      amount: "$ft",
    },
    {
      document: "Compte de résultat",
      categorie: "Charges d'exploitation",
      intitule: "Achats de matières premières et autres approvisionnements",
      code: "FU",
      amount: "$fu",
    },
    {
      document: "Compte de résultat",
      categorie: "Charges d'exploitation",
      intitule: "Variation de stock (matières premières et approvisionnements)",
      code: "FV",
      amount: "$fv",
    },
    {
      document: "Compte de résultat",
      categorie: "Charges d'exploitation",
      intitule: "Autres achats et charges externes",
      code: "FW",
      amount: "$fw",
    },
    {
      document: "Compte de résultat",
      categorie: "Charges d'exploitation",
      intitule: "Impôts, taxes et versements assimilés",
      code: "FX",
      amount: "$fx",
    },
    {
      document: "Compte de résultat",
      categorie: "Charges d'exploitation",
      intitule: "Salaires et traitements",
      code: "FY",
      amount: "$fy",
    },
    {
      document: "Compte de résultat",
      categorie: "Charges d'exploitation",
      intitule: "Charges sociales",
      code: "FZ",
      amount: "$fz",
    },
    {
      document: "Compte de résultat",
      categorie: "Charges d'exploitation : Dotations/amortissements",
      intitule: "Dotations aux amortissements",
      code: "GA",
      amount: "$ga",
    },
    {
      document: "Compte de résultat",
      categorie: "Charges d'exploitation : Dotations/amortissements",
      intitule: "Dotations aux provisions",
      code: "GB",
      amount: "$gb",
    },
    {
      document: "Compte de résultat",
      categorie: "Charges d'exploitation : Dotations/Actif circulant",
      intitule: "Dotations aux provisions",
      code: "GC",
      amount: "$gc",
    },
    {
      document: "Compte de résultat",
      categorie: "Charges d'exploitation : Dotations/Risques et charges",
      intitule: "Dotations aux provisions",
      code: "GD",
      amount: "$gd",
    },
    {
      document: "Compte de résultat",
      categorie: "Charges d'exploitation",
      intitule: "Autres charges",
      code: "GE",
      amount: "$ge",
    },
    {
      document: "Compte de résultat",
      categorie: "Produits financiers",
      intitule: "Reprises sur provisions et transferts de charges",
      code: "GM",
      amount: "$gm",
    },
    {
      document: "Compte de résultat",
      categorie: "Produits financiers",
      intitule: "Total des produits financiers",
      code: "GP",
      amount: "$gp",
    },
    {
      document: "Compte de résultat",
      categorie: "Charges financières",
      intitule: "Dotations financières aux amortissements et provisions",
      code: "GQ",
      amount: "$gq",
    },
    {
      document: "Compte de résultat",
      categorie: "Charges financières",
      intitule: "Total des charges financières",
      code: "GU",
      amount: "$gu",
    },
    {
      document: "Compte de résultat",
      categorie: "Produits exceptionnels",
      intitule: "Produits exceptionnels sur opérations en capital",
      code: "HB",
      amount: "$hb",
    },
    {
      document: "Compte de résultat",
      categorie: "Produits exceptionnels",
      intitule: "Reprises sur provisions et transferts de charges",
      code: "HC",
      amount: "$hc",
    },
    {
      document: "Compte de résultat",
      categorie: "Produits exceptionnels",
      intitule: "Total produits exceptionnels",
      code: "HD",
      amount: "$hd",
    },
    {
      document: "Compte de résultat",
      categorie: "Charges exceptionnelles",
      intitule: "Charges exceptionnelles sur opérations en capital",
      code: "HF",
      amount: "$hf",
    },
    {
      document: "Compte de résultat",
      categorie: "Charges exceptionnelles",
      intitule: "Dotations exceptionnelles aux amortissements et provisions",
      code: "HG",
      amount: "$hg",
    },
    {
      document: "Compte de résultat",
      categorie: "Charges exceptionnelles",
      intitule: "Total charges exceptionnelles",
      code: "HH",
      amount: "$hh",
    },
    {
      document: "Compte de résultat",
      categorie: "-",
      intitule: "Participation des salariés aux résultats de l'entreprise",
      code: "HJ",
      amount: "$hj",
    },
    { document: "Compte de résultat", categorie: "-", intitule: "Impôts sur les bénéfices", code: "HK", amount: "$hk" },
    {
      document: "Compte de résultat",
      categorie: "Total produits - Total charges",
      intitule: "Bénéfice ou Perte",
      code: "HN",
      amount: "$hn",
    },
    {
      document: "Compte de résultat",
      categorie: "Immobilisations",
      intitule: "Acquisitions, créations, apports et virements de poste à poste",
      code: "QJ",
      amount: "$qj",
    },
    {
      document: "Compte de résultat",
      categorie: "Détails de et charges externes",
      intitule: "Rémunérations d'intermédiaires et honoraires (hors personnel extérieur à l'entreprise)",
      code: "SS",
      amount: "$ss",
    },
    {
      document: "Compte de résultat",
      categorie: "Détails de et charges externes",
      intitule: "Autres comptes (dont cotisations versées aux organisations professionnelles)",
      code: "ST",
      amount: "$st",
    },
    {
      document: "Compte de résultat",
      categorie: "Détails de et charges externes",
      intitule: "Location et copropriété",
      code: "XQ",
      amount: "$xq",
    },
    {
      document: "Compte de résultat",
      categorie: "Divers",
      intitule: "Effectif moyen du personnel",
      code: "YP",
      amount: "$yp",
    },
    {
      document: "Compte de résultat",
      categorie: "Détails de et charges externes",
      intitule: "Sous-traitance",
      code: "YT",
      amount: "$yt",
    },
    {
      document: "Compte de résultat",
      categorie: "Détails de et charges externes",
      intitule: "Personnel extérieur à l'entreprise",
      code: "YU",
      amount: "$yu",
    },
    {
      document: "Compte de résultat",
      categorie: "Détails de et charges externes",
      intitule: "Rétrocessions d'honoraires, commissions et courtages",
      code: "YV",
      amount: "$yv",
    },
    {
      document: "Compte de résultat",
      categorie: "T.V.A",
      intitule: "Montant de la TVA collectée",
      code: "YY",
      amount: "$yy",
    },
    {
      document: "Compte de résultat",
      categorie: "T.V.A",
      intitule: "Montant de la TVA sur les achats comptabilisés au cours de l'exercice",
      code: "YZ",
      amount: "$yz",
    },
    { document: "Compte de résultat", categorie: "-", intitule: "Résultat d'exploitation", code: "GG", amount: "$gg" },
  ]

  // Backend subgrade values (0-10 scale) from ProcessDocumentJob calculations
  const subgradeValues = {
    financialIndependence: 6, // $subgradeFinancialIndependence
    repaymentCapacity: 8, // $subgradeRepaymentCapacity
    roe: 8, // $subgradeROE
    margin: 2.5, // $subgradeTheMargin
    debt: 2.5, // $subgradeDebt
    ebeCA: 5, // $subgradeEBECA
    immediateLiquidity: 1, // $subgradeImmediateLiquidity
    customerPaymentTime: 0.0, // $subgradeCustomerPaymentTime
    generalLiquidity: 4.0, // $subgradeGeneralLiquidity
  }

  // Backend validation results from ProcessDocumentJob
  const validationResults = {
    financialIndependence: "Yes", // $validElementFinancialIndependence (fixed from "yes")
    repaymentCapacity: "No", // $validElementRepaymentCapacity
    roe: "Neutre", // $validElementROE
    margin: "Neutre", // $validElementTheMargin
    debt: "Neutre", // $validElementDebt
    ebeCA: "Neutre", // $validElementEBECA
    immediateLiquidity: "No", // $validElementImmediateLiquidityDays
    customerPaymentTime: "No", // $validElementCustomerPaymentTimeDays
    generalLiquidity: "Yes", // $validElementGeneralLiquidity
  }

  // Backend calculated category scores (from ProcessDocumentJob)
  const solvencyScore = 1 // $ratioNoteSolvency
  const profitabilityScore = 5 // $ratioNoteProfitability
  const liquidityScore = 2 // $ratioNoteLiquidity

  // Overall score as average of category scores
  const overallScore = Math.round((solvencyScore + profitabilityScore + liquidityScore) / 3)

  // Add after the validationResults object, create category validation mappings
  const categoryScoreResults = {
    profitability: {
      score: profitabilityScore,
      status: getStatusFromScoreRange(profitabilityScore),
    },
    solvency: {
      score: solvencyScore,
      status: getStatusFromScoreRange(solvencyScore),
    },
    liquidity: {
      score: liquidityScore,
      status: getStatusFromScoreRange(liquidityScore),
    },
    overall: {
      score: overallScore,
      status: getStatusFromScoreRange(overallScore),
    },
  }

  const backendValues = {
    financialIndependence: 0.6, // $financialIndependence
    repaymentCapacity: 2.5, // $repaymentCapacity
    roe: 0.15, // $roe
    margin: 0.05, // $margin
    debt: 1.2, // $debt
    ebeCA: 0.1, // $ebeca
    immediateLiquidity: 30, // $immediateLiquidity
    customerPaymentTime: 45, // $customerPaymentTime
    generalLiquidity: 1.5, // $generalLiquidity
    turnover: 1000000, // $turnover
    addedValue: 500000, // $addedValue
    ebe: 100000, // $ebe
    netResult: 50000, // $netResult
  }

  const subgradeData = [
    {
      metric: "Financial Independence",
      value: `${(backendValues.financialIndependence * 100).toFixed(1)}%`,
      subgrade: subgradeValues.financialIndependence,
      status: getStatusFromValidation(validationResults.financialIndependence),
      description:
        "Measures the proportion of assets financed by equity rather than debt. Low independence indicates high reliance on external financing.",
      impact:
        getStatusFromValidation(validationResults.financialIndependence) === STATUS_TYPES.EXCELLENT
          ? "Excellent - Strong equity financing reduces financial risk."
          : getStatusFromValidation(validationResults.financialIndependence) === STATUS_TYPES.MODERATE
            ? "Moderate - Balanced financing structure with room for improvement."
            : "Critical Risk - Heavy dependence on external financing increases vulnerability to market changes.",
    },
    {
      metric: "Repayment Capacity",
      value: `${backendValues.repaymentCapacity} years`,
      subgrade: subgradeValues.repaymentCapacity,
      status: getStatusFromValidation(validationResults.repaymentCapacity),
      description:
        "Number of years needed to repay total debt using current cash flow. Longer periods indicate weaker debt servicing ability.",
      impact:
        getStatusFromValidation(validationResults.repaymentCapacity) === STATUS_TYPES.EXCELLENT
          ? "Excellent - Strong ability to service debt obligations."
          : getStatusFromValidation(validationResults.repaymentCapacity) === STATUS_TYPES.MODERATE
            ? "Moderate - Adequate debt servicing capability with some constraints."
            : "Critical Risk - Extended repayment period suggests potential cash flow constraints.",
    },
    {
      metric: "ROE (Return On Equity)",
      value: `${(backendValues.roe * 100).toFixed(1)}%`,
      subgrade: subgradeValues.roe,
      status: getStatusFromValidation(validationResults.roe),
      description:
        "Measures profitability relative to shareholders' equity. Indicates how effectively the company generates profits from equity investments.",
      impact:
        getStatusFromValidation(validationResults.roe) === STATUS_TYPES.EXCELLENT
          ? "Excellent - Strong returns on equity investment."
          : getStatusFromValidation(validationResults.roe) === STATUS_TYPES.MODERATE
            ? "Moderate - Acceptable returns with potential for optimization."
            : "Critical Risk - Poor returns on equity investment, significant concerns.",
    },
    {
      metric: "The Margin",
      value: `${(backendValues.margin * 100).toFixed(1)}%`,
      subgrade: subgradeValues.margin,
      status: getStatusFromValidation(validationResults.margin),
      description:
        "Net profit margin showing percentage of revenue retained as profit after all expenses. Key indicator of operational efficiency.",
      impact:
        getStatusFromValidation(validationResults.margin) === STATUS_TYPES.EXCELLENT
          ? "Excellent - Strong profit margins indicate efficient operations."
          : getStatusFromValidation(validationResults.margin) === STATUS_TYPES.MODERATE
            ? "Moderate - Acceptable margins with room for operational improvements."
            : "Critical Risk - Poor profit margins threaten business sustainability.",
    },
    {
      metric: "Debt Ratio",
      value: `${backendValues.debt.toFixed(1)}`,
      subgrade: subgradeValues.debt,
      status: getStatusFromValidation(validationResults.debt),
      description:
        "Ratio indicating debt levels relative to business capacity. Higher ratios indicate greater financial risk and leverage.",
      impact:
        getStatusFromValidation(validationResults.debt) === STATUS_TYPES.EXCELLENT
          ? "Excellent - Well-managed debt levels support financial stability."
          : getStatusFromValidation(validationResults.debt) === STATUS_TYPES.MODERATE
            ? "Moderate - Manageable debt levels requiring monitoring."
            : "Critical Risk - Excessive debt levels threaten financial stability and flexibility.",
    },
    {
      metric: "EBE / CA",
      value: `${(backendValues.ebeCA * 100).toFixed(1)}%`,
      subgrade: subgradeValues.ebeCA,
      status: getStatusFromValidation(validationResults.ebeCA),
      description:
        "Earnings Before Interest (EBE) as percentage of Total Assets (CA). Measures operational efficiency and asset utilization.",
      impact:
        getStatusFromValidation(validationResults.ebeCA) === STATUS_TYPES.EXCELLENT
          ? "Excellent - Strong asset utilization and operational efficiency."
          : getStatusFromValidation(validationResults.ebeCA) === STATUS_TYPES.MODERATE
            ? "Moderate - Adequate operational efficiency with improvement potential."
            : "Critical Risk - Poor asset utilization indicates operational inefficiencies.",
    },
    {
      metric: "Immediate Liquidity",
      value: `${backendValues.immediateLiquidity} days`,
      subgrade: subgradeValues.immediateLiquidity,
      status: getStatusFromValidation(validationResults.immediateLiquidity),
      description:
        "Days of cash and equivalents available to cover immediate obligations. Measures short-term financial flexibility.",
      impact:
        getStatusFromValidation(validationResults.immediateLiquidity) === STATUS_TYPES.EXCELLENT
          ? "Excellent - Strong immediate liquidity provides financial flexibility."
          : getStatusFromValidation(validationResults.immediateLiquidity) === STATUS_TYPES.MODERATE
            ? "Moderate - Adequate liquidity with some short-term constraints."
            : "Critical Risk - Insufficient immediate liquidity threatens short-term operations.",
    },
    {
      metric: "Customer Payment Time",
      value: `${backendValues.customerPaymentTime} days`,
      subgrade: subgradeValues.customerPaymentTime,
      status: getStatusFromValidation(validationResults.customerPaymentTime),
      description:
        "Average days to collect receivables from customers. Shorter periods indicate efficient collection processes.",
      impact:
        getStatusFromValidation(validationResults.customerPaymentTime) === STATUS_TYPES.EXCELLENT
          ? "Excellent - Efficient customer payment collection enhances cash flow."
          : getStatusFromValidation(validationResults.customerPaymentTime) === STATUS_TYPES.MODERATE
            ? "Moderate - Acceptable collection times with room for improvement."
            : "Critical Risk - Slow customer payment collection threatens cash flow management.",
    },
    {
      metric: "General Liquidity",
      value: `${backendValues.generalLiquidity}`,
      subgrade: subgradeValues.generalLiquidity,
      status: getStatusFromValidation(validationResults.generalLiquidity),
      description:
        "Current ratio measuring ability to pay short-term obligations. Higher ratios indicate better short-term financial health.",
      impact:
        getStatusFromValidation(validationResults.generalLiquidity) === STATUS_TYPES.EXCELLENT
          ? "Excellent - Strong ability to meet short-term obligations."
          : getStatusFromValidation(validationResults.generalLiquidity) === STATUS_TYPES.MODERATE
            ? "Moderate - Adequate short-term financial position."
            : "Critical Risk - Poor ability to meet short-term obligations.",
    },
  ]

  const getStatusIcon = (status: string) => {
    switch (status) {
      case STATUS_TYPES.EXCELLENT:
        return <CheckCircle className="h-5 w-5 text-green-500" />
      case STATUS_TYPES.MODERATE:
        return <Minus className="h-5 w-5 text-yellow-500" />
      case STATUS_TYPES.CRITICAL:
        return <XCircle className="h-5 w-5 text-destructive" />
      default:
        return <Minus className="h-5 w-5 text-muted-foreground" />
    }
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case STATUS_TYPES.EXCELLENT:
        return (
          <Badge variant="outline" className="text-green-500 border-green-500">
            Excellent
          </Badge>
        )
      case STATUS_TYPES.MODERATE:
        return (
          <Badge variant="outline" className="text-yellow-600 border-yellow-600">
            Moderate
          </Badge>
        )
      case STATUS_TYPES.CRITICAL:
        return <Badge variant="destructive">Critical</Badge>
      default:
        return <Badge variant="outline">Unknown</Badge>
    }
  }

  // Backend calculated category scores (from ProcessDocumentJob)
  // const profitabilityScore = 5 // $ratioNoteProfitability
  // const solvencyScore = 8 // $ratioNoteSolvency
  // const liquidityScore = 2 // $ratioNoteLiquidity

  // Overall score as average of category scores
  // const overallScore = Math.round((solvencyScore + profitabilityScore + liquidityScore) / 3)

  // Dynamic styling functions
  const getOverallHealthStatus = (score: number) => {
    if (score >= 7)
      return {
        status: "EXCELLENT FINANCIAL HEALTH",
        color: "text-green-800",
        bgColor: "bg-green-50 border-green-200",
        iconColor: "text-green-600",
        message: "The supplier demonstrates excellent financial health across all key metrics.",
        borderColor: "border-l-green-500",
      }
    if (score >= 5)
      return {
        status: "GOOD FINANCIAL HEALTH",
        color: "text-blue-800",
        bgColor: "bg-blue-50 border-blue-200",
        iconColor: "text-blue-600",
        message: "The supplier shows good financial health with some areas for improvement.",
        borderColor: "border-l-blue-500",
      }
    if (score >= 3)
      return {
        status: "MODERATE FINANCIAL CONCERNS",
        color: "text-yellow-800",
        bgColor: "bg-yellow-50 border-yellow-200",
        iconColor: "text-yellow-600",
        message: "The supplier has moderate financial concerns requiring attention.",
        borderColor: "border-l-yellow-500",
      }
    return {
      status: "CRITICAL FINANCIAL RISKS",
      color: "text-red-800",
      bgColor: "bg-red-50 border-red-200",
      iconColor: "text-red-600",
      message: "The supplier presents significant financial risks requiring immediate evaluation.",
      borderColor: "border-l-red-500",
    }
  }

  const getCategoryStyle = (status: string) => {
    const statusValue = status

    if (statusValue === StatusLevel.EXCELLENT)
      return {
        bgColor: "bg-green-50 border-green-200",
        icon: CheckCircle,
        iconColor: "text-green-500",
        textColor: "text-green-500",
        label: "Excellent",
      }
    if (statusValue === StatusLevel.MODERATE)
      return {
        bgColor: "bg-yellow-50 border-yellow-200",
        icon: AlertTriangle,
        iconColor: "text-yellow-500",
        textColor: "text-yellow-600",
        label: "Moderate",
      }
    return {
      bgColor: "bg-red-50 border-red-200",
      icon: XCircle,
      iconColor: "text-red-500",
      textColor: "text-red-500",
      label: "Critical",
    }
  }

  const getRiskLevel = (score: number) => {
    if (score >= 7) return "Low Risk"
    if (score >= 5) return "Medium Risk"
    if (score >= 3) return "Moderate Risk"
    return "High Risk"
  }

  // Calculate actual risk summary
  const criticalIssues = subgradeData.filter((item) => item.status === STATUS_TYPES.CRITICAL).length
  const moderateIssues = subgradeData.filter((item) => item.status === STATUS_TYPES.MODERATE).length
  const positiveIndicators = subgradeData.filter((item) => item.status === STATUS_TYPES.EXCELLENT).length

  const healthStatus = getOverallHealthStatus(overallScore)
  const solvencyStyle = getCategoryStyle(categoryScoreResults.solvency.status)
  const profitabilityStyle = getCategoryStyle(categoryScoreResults.profitability.status)
  const liquidityStyle = getCategoryStyle(categoryScoreResults.liquidity.status)

  // Export functions
  const exportToPDF = async () => {
    setIsExporting(true)
    try {
      const pdfExporter = new PDFExporter()
      const exportOptions: ExportOptions = {
        supplierName: "Supplier_name",
        year: "2023",
        overallScore,
        profitabilityScore,
        solvencyScore,
        liquidityScore,
        subgradeData,
        financialMetrics: {
          turnover: `€${backendValues.turnover.toLocaleString()}`,
          addedValue: `€${backendValues.addedValue.toLocaleString()}`,
          ebe: `€${backendValues.ebe.toLocaleString()}`,
          netResult: `€${backendValues.netResult.toLocaleString()}`,
        },
      }

      await pdfExporter.exportToPDF(exportOptions)

      toast({
        title: "PDF Export Successful",
        description: "The financial analysis report has been downloaded as PDF.",
      })
    } catch (error) {
      console.error("PDF export error:", error)
      toast({
        title: "Export Failed",
        description: "There was an error generating the PDF report. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsExporting(false)
    }
  }

  const exportDashboardToPDF = async () => {
    setIsExporting(true)
    try {
      const pdfExporter = new PDFExporter()
      await pdfExporter.exportDashboardToPDF("dashboard-content", "Supplier_Dashboard_Screenshot.pdf")

      toast({
        title: "Dashboard Export Successful",
        description: "The dashboard screenshot has been downloaded as PDF.",
      })
    } catch (error) {
      console.error("Dashboard export error:", error)
      toast({
        title: "Export Failed",
        description: "There was an error exporting the dashboard. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsExporting(false)
    }
  }

  const exportToPPT = async () => {
    setIsExporting(true)
    try {
      const pptExporter = new PPTExporter()
      const exportOptions: PPTExportOptions = {
        supplierName: "Supplier_name",
        year: "2023",
        overallScore,
        profitabilityScore,
        solvencyScore,
        liquidityScore,
        subgradeData,
        financialMetrics: {
          turnover: `€${backendValues.turnover.toLocaleString()}`,
          addedValue: `€${backendValues.addedValue.toLocaleString()}`,
          ebe: `€${backendValues.ebe.toLocaleString()}`,
          netResult: `€${backendValues.netResult.toLocaleString()}`,
        },
      }

      await pptExporter.exportToPPT(exportOptions)

      toast({
        title: "PowerPoint Export Successful",
        description: "The financial analysis presentation has been downloaded as PPTX.",
      })
    } catch (error) {
      console.error("PowerPoint export error:", error)
      toast({
        title: "Export Failed",
        description: "There was an error generating the PowerPoint presentation. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsExporting(false)
    }
  }

  const exportToCSV = () => {
    // Convert financial data to CSV format
    const csvHeaders = ["Document", "Catégorie", "Intitulé", "Code", "Amount"]
    const csvData = financialData.map((row) => [row.document, row.categorie, row.intitule, row.code, row.amount])

    const csvContent = [csvHeaders, ...csvData].map((row) => row.map((field) => `"${field}"`).join(",")).join("\n")

    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" })
    const link = document.createElement("a")
    const url = URL.createObjectURL(blob)
    link.setAttribute("href", url)
    link.setAttribute("download", "financial_raw_data.csv")
    link.style.visibility = "hidden"
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)

    toast({
      title: "CSV Export Successful",
      description: "The raw financial data has been downloaded as CSV.",
    })
  }

  const renderTabContent = () => {
    switch (activeTab) {
      case "profitability":
        const profitabilityStatus = categoryScoreResults.profitability.status
        return (
          <div className="space-y-4">
            <div className={`flex items-center justify-between p-3 rounded-lg ${profitabilityStyle.bgColor}`}>
              <div className="flex items-center gap-3">
                <profitabilityStyle.icon className={`h-6 w-6 ${profitabilityStyle.iconColor}`} />
                <div>
                  <p className="font-medium">
                    {profitabilityStatus === StatusLevel.EXCELLENT
                      ? "Excellent Profitability"
                      : profitabilityStatus === StatusLevel.MODERATE
                        ? "Moderate Profitability"
                        : "Critical Profitability Issues"}
                  </p>
                  <p className="text-sm text-muted-foreground">
                    {profitabilityStatus === StatusLevel.EXCELLENT || profitabilityStatus === StatusLevel.MODERATE
                      ? "Above industry standards"
                      : "Below industry standards"}
                  </p>
                </div>
              </div>
              <Badge
                variant={profitabilityStatus === StatusLevel.CRITICAL ? "destructive" : "outline"}
                className={
                  profitabilityStatus !== StatusLevel.CRITICAL ? `${profitabilityStyle.textColor} border-current` : ""
                }
              >
                {profitabilityScore}/10
              </Badge>
            </div>
            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-sm">Net Margin</span>
                <span className="font-medium">{(backendValues.margin * 100).toFixed(1)}%</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm">ROE</span>
                <span className="font-medium">{(backendValues.roe * 100).toFixed(1)}%</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm">EBE/CA</span>
                <span className="font-medium">{(backendValues.ebeCA * 100).toFixed(1)}%</span>
              </div>
            </div>
          </div>
        )
      case "solvency":
        const solvencyStatus = categoryScoreResults.solvency.status
        return (
          <div className="space-y-4">
            <div className={`flex items-center justify-between p-3 rounded-lg ${solvencyStyle.bgColor}`}>
              <div className="flex items-center gap-3">
                <solvencyStyle.icon className={`h-6 w-6 ${solvencyStyle.iconColor}`} />
                <div>
                  <p className="font-medium">
                    {solvencyStatus === StatusLevel.EXCELLENT
                      ? "Excellent Solvency"
                      : solvencyStatus === StatusLevel.MODERATE
                        ? "Moderate Solvency"
                        : "Critical Solvency Issues"}
                  </p>
                  <p className="text-sm text-muted-foreground">
                    {solvencyStatus === StatusLevel.EXCELLENT || solvencyStatus === StatusLevel.MODERATE
                      ? "Strong financial position"
                      : "High debt levels"}
                  </p>
                </div>
              </div>
              <Badge
                variant={solvencyStatus === StatusLevel.CRITICAL ? "destructive" : "outline"}
                className={solvencyStatus !== StatusLevel.CRITICAL ? `${solvencyStyle.textColor} border-current` : ""}
              >
                {solvencyScore}/10
              </Badge>
            </div>
            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-sm">Financial Independence</span>
                <span className="font-medium">{(backendValues.financialIndependence * 100).toFixed(1)}%</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm">Repayment Capacity</span>
                <span className="font-medium">{backendValues.repaymentCapacity} years</span>
              </div>
            </div>
          </div>
        )
      case "liquidity":
        const liquidityStatus = categoryScoreResults.liquidity.status
        return (
          <div className="space-y-4">
            <div className={`flex items-center justify-between p-3 rounded-lg ${liquidityStyle.bgColor}`}>
              <div className="flex items-center gap-3">
                <liquidityStyle.icon className={`h-6 w-6 ${liquidityStyle.iconColor}`} />
                <div>
                  <p className="font-medium">
                    {liquidityStatus === StatusLevel.EXCELLENT
                      ? "Excellent Liquidity"
                      : liquidityStatus === StatusLevel.MODERATE
                        ? "Moderate Liquidity"
                        : "Critical Liquidity Issues"}
                  </p>
                  <p className="text-sm text-muted-foreground">
                    {liquidityStatus === StatusLevel.EXCELLENT || liquidityStatus === StatusLevel.MODERATE
                      ? "Strong short-term position"
                      : "Weak short-term position"}
                  </p>
                </div>
              </div>
              <Badge
                variant={liquidityStatus === StatusLevel.CRITICAL ? "destructive" : "outline"}
                className={liquidityStatus !== StatusLevel.CRITICAL ? `${liquidityStyle.textColor} border-current` : ""}
              >
                {liquidityScore}/10
              </Badge>
            </div>
            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-sm">Immediate Liquidity</span>
                <span className="font-medium">{backendValues.immediateLiquidity} days</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm">Customer Payment Time</span>
                <span className="font-medium">{backendValues.customerPaymentTime} days</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm">General Liquidity</span>
                <span className="font-medium">{backendValues.generalLiquidity}</span>
              </div>
            </div>
          </div>
        )
      default:
        return null
    }
  }

  return (
    <div className="flex min-h-screen flex-col bg-muted/40">
      <header className="sticky top-0 z-10 flex h-16 items-center gap-4 border-b bg-background px-6">
        <h1 className="text-xl font-semibold">Supplier Financial Analysis</h1>
        <div className="ml-auto flex items-center gap-4">
          <div className="w-[220px] border rounded-md px-3 py-2 text-sm">Supplier_name</div>
          <div className="w-[120px] border rounded-md px-3 py-2 text-sm">2023</div>

          {/* Export Dropdown */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" className="gap-2 bg-transparent" disabled={isExporting}>
                {isExporting ? <Loader2 className="h-4 w-4 animate-spin" /> : <Download className="h-4 w-4" />}
                Export
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-56">
              <DropdownMenuItem onClick={exportToPDF} className="gap-2" disabled={isExporting}>
                <FileText className="h-4 w-4" />
                Export Analysis to PDF
              </DropdownMenuItem>
              <DropdownMenuItem onClick={exportDashboardToPDF} className="gap-2" disabled={isExporting}>
                <FileText className="h-4 w-4" />
                Export Dashboard Screenshot
              </DropdownMenuItem>
              <DropdownMenuItem onClick={exportToPPT} className="gap-2" disabled={isExporting}>
                <Presentation className="h-4 w-4" />
                Export to PowerPoint
              </DropdownMenuItem>
              <DropdownMenuItem onClick={exportToCSV} className="gap-2" disabled={isExporting}>
                <FileSpreadsheet className="h-4 w-4" />
                Export Raw Data (CSV)
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </header>
      <main id="dashboard-content" className="flex-1 p-6 grid gap-6">
        {/* Executive Summary Section */}
        <Card className={`border-l-4 ${healthStatus.borderColor}`}>
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="text-2xl flex items-center gap-2">
                  <Activity className={`h-6 w-6 ${healthStatus.iconColor}`} />
                  Executive Summary
                </CardTitle>
                <CardDescription className="text-base mt-2">
                  Overall financial health assessment for supplier evaluation
                </CardDescription>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="grid gap-6 md:grid-cols-4">
              {/* Overall Rating */}
              <div className="flex flex-col items-center justify-center space-y-4">
                <div className="relative flex h-32 w-32 items-center justify-center rounded-full">
                  <svg className="h-32 w-32" viewBox="0 0 100 100">
                    <circle className="stroke-muted" cx="50" cy="50" r="45" strokeWidth="8" fill="none" />
                    <circle
                      className={
                        overallScore >= 7
                          ? "stroke-green-500"
                          : overallScore >= 5
                            ? "stroke-blue-500"
                            : overallScore >= 3
                              ? "stroke-yellow-500"
                              : "stroke-red-500"
                      }
                      cx="50"
                      cy="50"
                      r="45"
                      strokeWidth="8"
                      fill="none"
                      strokeDasharray="282.7"
                      strokeDashoffset={282.7 - (282.7 * overallScore) / 10}
                      transform="rotate(-90 50 50)"
                    />
                  </svg>
                  <div className="absolute flex flex-col items-center justify-center">
                    <span className="text-3xl font-bold">{overallScore}</span>
                    <span className="text-xs text-muted-foreground">/10</span>
                  </div>
                </div>
                <div className="text-center">
                  <h3 className="font-semibold">Overall Rating</h3>
                  <p className="text-sm text-muted-foreground">{getRiskLevel(overallScore)}</p>
                </div>
              </div>

              {/* Key Metrics Grid */}
              <div className="md:col-span-2 grid gap-4">
                <div className="grid grid-cols-3 gap-4">
                  {/* Solvency */}
                  <div className={`text-center p-4 rounded-lg border ${solvencyStyle.bgColor}`}>
                    <div className="flex items-center justify-center mb-2">
                      <solvencyStyle.icon className={`h-8 w-8 ${solvencyStyle.iconColor}`} />
                    </div>
                    <h4 className="font-semibold text-sm mb-1">Solvency</h4>
                    <div className={`text-2xl font-bold ${solvencyStyle.textColor}`}>{solvencyScore}/10</div>
                    <Progress value={(solvencyScore / 10) * 100} className="h-2 mt-2" />
                    <p className="text-xs text-muted-foreground mt-1">{solvencyStyle.label}</p>
                  </div>

                  {/* Profitability */}
                  <div className={`text-center p-4 rounded-lg border ${profitabilityStyle.bgColor}`}>
                    <div className="flex items-center justify-center mb-2">
                      <profitabilityStyle.icon className={`h-8 w-8 ${profitabilityStyle.iconColor}`} />
                    </div>
                    <h4 className="font-semibold text-sm mb-1">Profitability</h4>
                    <div className={`text-2xl font-bold ${profitabilityStyle.textColor}`}>{profitabilityScore}/10</div>
                    <Progress value={(profitabilityScore / 10) * 100} className="h-2 mt-2" />
                    <p className="text-xs text-muted-foreground mt-1">{profitabilityStyle.label}</p>
                  </div>

                  {/* Liquidity */}
                  <div className={`text-center p-4 rounded-lg border ${liquidityStyle.bgColor}`}>
                    <div className="flex items-center justify-center mb-2">
                      <liquidityStyle.icon className={`h-8 w-8 ${liquidityStyle.iconColor}`} />
                    </div>
                    <h4 className="font-semibold text-sm mb-1">Liquidity</h4>
                    <div className={`text-2xl font-bold ${liquidityStyle.textColor}`}>{liquidityScore}/10</div>
                    <Progress value={(liquidityScore / 10) * 100} className="h-2 mt-2" />
                    <p className="text-xs text-muted-foreground mt-1">{liquidityStyle.label}</p>
                  </div>
                </div>

                {/* Financial Health Assessment */}
                <div className={`p-4 rounded-lg border ${healthStatus.bgColor}`}>
                  <div className="flex items-center gap-2 mb-2">
                    {overallScore >= 7 ? (
                      <CheckCircle className={`h-5 w-5 ${healthStatus.iconColor}`} />
                    ) : overallScore >= 3 ? (
                      <AlertTriangle className={`h-5 w-5 ${healthStatus.iconColor}`} />
                    ) : (
                      <XCircle className={`h-5 w-5 ${healthStatus.iconColor}`} />
                    )}
                    <h4 className={`font-semibold ${healthStatus.color}`}>{healthStatus.status}</h4>
                  </div>
                  <p className={`text-sm ${healthStatus.color.replace("800", "700")}`}>{healthStatus.message}</p>
                </div>
              </div>

              {/* Risk Summary */}
              <div className="space-y-4 border-l-4 border-l-slate-300 pl-4 bg-slate-50/50 rounded-r-lg py-2">
                <h4 className="font-semibold text-center text-slate-700">Risk Summary</h4>
                <div className="space-y-3">
                  <div className="flex items-center justify-between p-2 rounded border bg-red-50 border-red-200">
                    <span className="text-sm font-medium">Critical Issues</span>
                    <Badge variant="destructive" className="text-xs">
                      {criticalIssues}
                    </Badge>
                  </div>
                  <div className="flex items-center justify-between p-2 rounded border bg-yellow-50 border-yellow-200">
                    <span className="text-sm font-medium">Moderate Issues</span>
                    <Badge variant="outline" className="text-yellow-600 border-yellow-600 text-xs">
                      {moderateIssues}
                    </Badge>
                  </div>
                  <div className="flex items-center justify-between p-2 rounded border bg-green-50 border-green-200">
                    <span className="text-sm font-medium">Positive Indicators</span>
                    <Badge variant="outline" className="text-green-500 border-green-500 text-xs">
                      {positiveIndicators}
                    </Badge>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Financial Metrics Section */}
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <TrendingUp className="h-5 w-5 text-green-500" />
                Key Financial Metrics
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <p className="text-sm text-muted-foreground">Turnover</p>
                    <p className="text-2xl font-bold">€{backendValues.turnover.toLocaleString()}</p>
                    <div className="flex items-center text-sm text-green-500">
                      <ArrowUp className="mr-1 h-4 w-4" />
                      <span>+5.2% YoY</span>
                    </div>
                  </div>
                  <div className="space-y-1">
                    <p className="text-sm text-muted-foreground">Added Value</p>
                    <p className="text-2xl font-bold">€{backendValues.addedValue.toLocaleString()}</p>
                    <div className="flex items-center text-sm text-green-500">
                      <ArrowUp className="mr-1 h-4 w-4" />
                      <span>+3.8% YoY</span>
                    </div>
                  </div>
                </div>
                <Separator />
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <p className="text-sm text-muted-foreground">EBE</p>
                    <p className="text-2xl font-bold">€{backendValues.ebe.toLocaleString()}</p>
                    <div className="flex items-center text-sm text-green-500">
                      <ArrowUp className="mr-1 h-4 w-4" />
                      <span>+2.1% YoY</span>
                    </div>
                  </div>
                  <div className="space-y-1">
                    <p className="text-sm text-muted-foreground">Net Result</p>
                    <p className="text-2xl font-bold">€{backendValues.netResult.toLocaleString()}</p>
                    <div className="flex items-center text-sm text-green-500">
                      <ArrowUp className="mr-1 h-4 w-4" />
                      <span>+4.3% YoY</span>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle>Financial Analysis</CardTitle>
              <div className="flex border rounded-md mt-2 overflow-hidden">
                <button
                  onClick={() => setActiveTab("profitability")}
                  className={`flex-1 text-center py-2 px-3 font-medium text-sm transition-colors ${
                    activeTab === "profitability" ? "bg-primary text-primary-foreground" : "hover:bg-muted/50"
                  }`}
                >
                  Profitability
                </button>
                <button
                  onClick={() => setActiveTab("solvency")}
                  className={`flex-1 text-center py-2 px-3 font-medium text-sm transition-colors ${
                    activeTab === "solvency" ? "bg-primary text-primary-foreground" : "hover:bg-muted/50"
                  }`}
                >
                  Solvency
                </button>
                <button
                  onClick={() => setActiveTab("liquidity")}
                  className={`flex-1 text-center py-2 px-3 font-medium text-sm transition-colors ${
                    activeTab === "liquidity" ? "bg-primary text-primary-foreground" : "hover:bg-muted/50"
                  }`}
                >
                  Liquidity
                </button>
              </div>
            </CardHeader>
            <CardContent>{renderTabContent()}</CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                {positiveIndicators > 0 ? (
                  <CheckCircle className="h-5 w-5 text-green-500" />
                ) : (
                  <XCircle className="h-5 w-5 text-red-500" />
                )}
                {positiveIndicators > 0 ? "Positive Indicators" : "Areas of Concern"}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {positiveIndicators > 0
                  ? subgradeData
                      .filter((item) => item.status === STATUS_TYPES.EXCELLENT)
                      .slice(0, 4)
                      .map((item, index) => (
                        <div
                          key={index}
                          className="flex items-center justify-between rounded-lg border p-3 bg-green-50"
                        >
                          <div className="flex items-center gap-3">
                            <CheckCircle className="h-5 w-5 text-green-500" />
                            <span className="font-medium">{item.metric}</span>
                          </div>
                          <Badge variant="outline" className="text-green-500 border-green-500">
                            Excellent
                          </Badge>
                        </div>
                      ))
                  : subgradeData
                      .filter((item) => item.status === STATUS_TYPES.CRITICAL)
                      .slice(0, 4)
                      .map((item, index) => (
                        <div key={index} className="flex items-center justify-between rounded-lg border p-3 bg-red-50">
                          <div className="flex items-center gap-3">
                            <XCircle className="h-5 w-5 text-red-500" />
                            <span className="font-medium">{item.metric}</span>
                          </div>
                          <Badge variant="destructive">Critical</Badge>
                        </div>
                      ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Detailed Analysis Section */}
        <Card>
          <CardHeader>
            <CardTitle className="text-2xl flex items-center gap-2">
              <Activity className="h-6 w-6" />
              Comprehensive Subgrade Analysis
            </CardTitle>
            <CardDescription className="text-base">
              Detailed evaluation of key financial metrics to assess supplier profitability and financial health
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow className="bg-muted/50">
                    <TableHead className="w-[200px] font-semibold">Financial Metric</TableHead>
                    <TableHead className="text-center font-semibold">Current Value</TableHead>
                    <TableHead className="text-center font-semibold">Subgrade</TableHead>
                    <TableHead className="text-center font-semibold">Status</TableHead>
                    <TableHead className="w-[300px] font-semibold">Description & Impact</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {subgradeData.map((item, index) => (
                    <TableRow key={index} className="hover:bg-muted/30 transition-colors">
                      <TableCell className="font-medium">
                        <div className="flex items-center gap-2">
                          {getStatusIcon(item.status)}
                          <span>{item.metric}</span>
                        </div>
                      </TableCell>
                      <TableCell className="text-center font-mono font-semibold text-base">{item.value}</TableCell>
                      <TableCell className="text-center font-mono font-semibold text-base">
                        {item.subgrade.toFixed(1)}/10
                      </TableCell>
                      <TableCell className="text-center">{getStatusBadge(item.status)}</TableCell>
                      <TableCell>
                        <div className="space-y-2">
                          <p className="text-sm leading-relaxed">{item.description}</p>
                          <p className="text-xs text-muted-foreground font-medium bg-muted/30 p-2 rounded">
                            {item.impact}
                          </p>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>

        {/* Raw Financial Data Section */}
        <Card>
          <CardHeader>
            <CardTitle className="text-2xl flex items-center gap-2">
              <FileSpreadsheet className="h-6 w-6" />
              Raw Financial Data Structure
            </CardTitle>
            <CardDescription className="text-base">
              Complete financial data structure with dynamic amount variables based on codes
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="mb-4">
              <img
                src="/images/financial-data-structure.png"
                alt="Financial Data Structure Reference"
                className="w-full max-w-4xl mx-auto border rounded-lg shadow-sm"
              />
            </div>
            <div className="text-sm text-muted-foreground mb-4">
              <p>
                <strong>Note:</strong> Amount values are dynamically populated using variables based on the code column
                (e.g., code 'BJ' → amount '$bj')
              </p>
            </div>
            <div className="overflow-x-auto max-h-96">
              <Table>
                <TableHeader>
                  <TableRow className="bg-muted/50">
                    <TableHead className="w-[200px]">Document</TableHead>
                    <TableHead className="w-[150px]">Catégorie</TableHead>
                    <TableHead className="w-[300px]">Intitulé</TableHead>
                    <TableHead className="w-[80px]">Code</TableHead>
                    <TableHead className="w-[120px]">Amount</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {financialData.map((row, index) => (
                    <TableRow key={index} className="hover:bg-muted/30">
                      <TableCell className="font-medium">{row.document}</TableCell>
                      <TableCell className="text-muted-foreground">{row.categorie}</TableCell>
                      <TableCell>{row.intitule}</TableCell>
                      <TableCell className="uppercase">{row.code}</TableCell>
                      <TableCell className="font-mono">{row.amount}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      </main>
    </div>
  )
}
