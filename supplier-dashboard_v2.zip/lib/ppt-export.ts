// Use dynamic import to handle pptxgenjs properly
export interface PPTExportOptions {
  supplierName: string
  year: string
  overallScore: number
  profitabilityScore: number
  solvencyScore: number
  liquidityScore: number
  subgradeData: Array<{
    metric: string
    value: string
    subgrade: number
    status: string
    description: string
    impact: string
  }>
  financialMetrics: {
    turnover: string
    addedValue: string
    ebe: string
    netResult: string
  }
}

// Status Management Constants
const STATUS_TYPES = {
  EXCELLENT: "excellent",
  MODERATE: "moderate",
  CRITICAL: "critical",
} as const

export class PPTExporter {
  private pptx: any
  private brandColors = {
    primary: "2563EB",
    success: "22C55E",
    danger: "EF4444",
    warning: "F59E0B",
    muted: "6B7280",
    background: "F8FAFC",
    white: "FFFFFF",
    dark: "1F2937",
  }

  constructor() {
    // Initialize as null, will be set in setupPresentation
    this.pptx = null
  }

  private async setupPresentation(): Promise<void> {
    // Dynamic import to handle module loading
    const PptxGenJS = (await import("pptxgenjs")).default
    this.pptx = new PptxGenJS()

    this.pptx.author = "Financial Analysis System"
    this.pptx.company = "Supplier Analysis Platform"
    this.pptx.revision = "1"
    this.pptx.subject = "Supplier Financial Analysis Report"
    this.pptx.title = "Financial Analysis Presentation"
  }

  private getScoreColor(score: number): string {
    if (score > 7) return this.brandColors.success
    if (score > 4) return this.brandColors.warning
    return this.brandColors.danger
  }

  private getStatusColor(status: string): string {
    switch (status) {
      case STATUS_TYPES.EXCELLENT:
        return this.brandColors.success
      case STATUS_TYPES.MODERATE:
        return this.brandColors.warning
      case STATUS_TYPES.CRITICAL:
        return this.brandColors.danger
      default:
        return this.brandColors.muted
    }
  }

  private addTitleSlide(options: PPTExportOptions): void {
    const slide = this.pptx.addSlide()

    // Background
    slide.background = { color: this.brandColors.primary }

    // Main title
    slide.addText("Supplier Financial Analysis", {
      x: 1,
      y: 1.5,
      w: 8,
      h: 1,
      fontSize: 36,
      bold: true,
      color: this.brandColors.white,
      align: "center",
    })

    // Supplier name
    slide.addText(options.supplierName, {
      x: 1,
      y: 2.7,
      w: 8,
      h: 0.8,
      fontSize: 28,
      color: this.brandColors.white,
      align: "center",
    })

    // Year and date
    slide.addText(`Analysis Year: ${options.year}`, {
      x: 1,
      y: 3.7,
      w: 4,
      h: 0.5,
      fontSize: 16,
      color: this.brandColors.white,
      align: "center",
    })

    slide.addText(`Generated: ${new Date().toLocaleDateString()}`, {
      x: 5,
      y: 3.7,
      w: 4,
      h: 0.5,
      fontSize: 16,
      color: this.brandColors.white,
      align: "center",
    })

    // Overall score
    slide.addText(`Overall Score: ${options.overallScore}/10`, {
      x: 3.5,
      y: 4.5,
      w: 3,
      h: 0.8,
      fontSize: 24,
      bold: true,
      color: this.brandColors.white,
      align: "center",
    })
  }

  private addExecutiveSummarySlide(options: PPTExportOptions): void {
    const slide = this.pptx.addSlide()

    // Header
    slide.addText("Executive Summary", {
      x: 0.5,
      y: 0.3,
      w: 9,
      h: 0.6,
      fontSize: 28,
      bold: true,
      color: this.brandColors.dark,
    })

    // Overall rating section
    slide.addText("Overall Financial Health", {
      x: 0.5,
      y: 1.2,
      w: 4,
      h: 0.4,
      fontSize: 18,
      bold: true,
      color: this.brandColors.dark,
    })

    // Score display
    const scores = [
      { label: "Overall", score: options.overallScore, x: 0.5 },
      { label: "Profitability", score: options.profitabilityScore, x: 2.5 },
      { label: "Solvency", score: options.solvencyScore, x: 4.5 },
      { label: "Liquidity", score: options.liquidityScore, x: 6.5 },
    ]

    scores.forEach((item) => {
      const color = this.getScoreColor(item.score)

      // Score text with background
      slide.addText(`${item.score}/10`, {
        x: item.x,
        y: 1.8,
        w: 1.5,
        h: 0.6,
        fontSize: 16,
        bold: true,
        color: this.brandColors.white,
        align: "center",
        fill: { color: color },
      })

      // Label
      slide.addText(item.label, {
        x: item.x,
        y: 2.5,
        w: 1.5,
        h: 0.3,
        fontSize: 10,
        color: this.brandColors.dark,
        align: "center",
      })
    })

    // Risk assessment
    const criticalIssues = options.subgradeData.filter((item) => item.status === STATUS_TYPES.CRITICAL).length
    const positiveIndicators = options.subgradeData.filter((item) => item.status === STATUS_TYPES.EXCELLENT).length

    slide.addText("Risk Assessment", {
      x: 0.5,
      y: 3.2,
      w: 4,
      h: 0.4,
      fontSize: 18,
      bold: true,
      color: this.brandColors.dark,
    })

    slide.addText(`Critical Issues: ${criticalIssues}`, {
      x: 0.5,
      y: 3.7,
      w: 3,
      h: 0.3,
      fontSize: 14,
      color: criticalIssues > 0 ? this.brandColors.danger : this.brandColors.success,
    })

    slide.addText(`Positive Indicators: ${positiveIndicators}`, {
      x: 4,
      y: 3.7,
      w: 3,
      h: 0.3,
      fontSize: 14,
      color: this.brandColors.success,
    })

    // Risk level
    const riskLevel = options.overallScore > 7 ? "Low Risk" : options.overallScore > 4 ? "Medium Risk" : "High Risk"
    const riskColor =
      options.overallScore > 7
        ? this.brandColors.success
        : options.overallScore > 4
          ? this.brandColors.warning
          : this.brandColors.danger

    slide.addText(`Overall Risk Level: ${riskLevel}`, {
      x: 0.5,
      y: 4.2,
      w: 6,
      h: 0.3,
      fontSize: 14,
      bold: true,
      color: riskColor,
    })
  }

  private addFinancialMetricsSlide(options: PPTExportOptions): void {
    const slide = this.pptx.addSlide()

    // Header
    slide.addText("Key Financial Metrics", {
      x: 0.5,
      y: 0.3,
      w: 9,
      h: 0.6,
      fontSize: 28,
      bold: true,
      color: this.brandColors.dark,
    })

    // Metrics table data
    const metricsData = [
      [
        {
          text: "Metric",
          options: { bold: true, color: this.brandColors.white, fill: { color: this.brandColors.primary } },
        },
        {
          text: "Value",
          options: { bold: true, color: this.brandColors.white, fill: { color: this.brandColors.primary } },
        },
        {
          text: "YoY Change",
          options: { bold: true, color: this.brandColors.white, fill: { color: this.brandColors.primary } },
        },
      ],
      [
        { text: "Turnover", options: { color: this.brandColors.dark } },
        { text: options.financialMetrics.turnover, options: { color: this.brandColors.dark } },
        { text: "+5.2%", options: { color: this.brandColors.success } },
      ],
      [
        { text: "Added Value", options: { color: this.brandColors.dark } },
        { text: options.financialMetrics.addedValue, options: { color: this.brandColors.dark } },
        { text: "+3.8%", options: { color: this.brandColors.success } },
      ],
      [
        { text: "EBE", options: { color: this.brandColors.dark } },
        { text: options.financialMetrics.ebe, options: { color: this.brandColors.dark } },
        { text: "+2.1%", options: { color: this.brandColors.success } },
      ],
      [
        { text: "Net Result", options: { color: this.brandColors.dark } },
        { text: options.financialMetrics.netResult, options: { color: this.brandColors.dark } },
        { text: "+4.3%", options: { color: this.brandColors.success } },
      ],
    ]

    slide.addTable(metricsData, {
      x: 1,
      y: 1.5,
      w: 8,
      h: 3,
      fontSize: 14,
      border: { pt: 1, color: this.brandColors.muted },
      rowH: 0.6,
      colW: [2.5, 2.5, 3],
    })
  }

  private addSubgradeAnalysisSlide(options: PPTExportOptions): void {
    const slide = this.pptx.addSlide()

    // Header
    slide.addText("Subgrade Analysis Overview", {
      x: 0.5,
      y: 0.3,
      w: 9,
      h: 0.6,
      fontSize: 28,
      bold: true,
      color: this.brandColors.dark,
    })

    // Create table data with proper formatting
    const tableData = [
      [
        {
          text: "Metric",
          options: { bold: true, color: this.brandColors.white, fill: { color: this.brandColors.primary } },
        },
        {
          text: "Value",
          options: { bold: true, color: this.brandColors.white, fill: { color: this.brandColors.primary } },
        },
        {
          text: "Score",
          options: { bold: true, color: this.brandColors.white, fill: { color: this.brandColors.primary } },
        },
        {
          text: "Status",
          options: { bold: true, color: this.brandColors.white, fill: { color: this.brandColors.primary } },
        },
      ],
      ...options.subgradeData.map((item) => [
        { text: item.metric, options: { color: this.brandColors.dark } },
        { text: item.value, options: { color: this.brandColors.dark } },
        { text: `${item.subgrade.toFixed(1)}/10`, options: { color: this.brandColors.dark } },
        {
          text:
            item.status === STATUS_TYPES.EXCELLENT
              ? "Excellent"
              : item.status === STATUS_TYPES.MODERATE
                ? "Moderate"
                : "Critical",
          options: {
            color: this.brandColors.white,
            fill: { color: this.getStatusColor(item.status) },
          },
        },
      ]),
    ]

    slide.addTable(tableData, {
      x: 0.5,
      y: 1.2,
      w: 9,
      h: 4,
      fontSize: 11,
      border: { pt: 1, color: this.brandColors.muted },
      rowH: 0.4,
      colW: [2.5, 1.5, 1.5, 1.5],
    })
  }

  private addRecommendationsSlide(options: PPTExportOptions): void {
    const slide = this.pptx.addSlide()

    // Header
    slide.addText("Recommendations", {
      x: 0.5,
      y: 0.3,
      w: 9,
      h: 0.6,
      fontSize: 28,
      bold: true,
      color: this.brandColors.dark,
    })

    const criticalMetrics = options.subgradeData.filter((item) => item.status === STATUS_TYPES.CRITICAL)
    const excellentMetrics = options.subgradeData.filter((item) => item.status === STATUS_TYPES.EXCELLENT)
    const moderateMetrics = options.subgradeData.filter((item) => item.status === STATUS_TYPES.MODERATE)

    let yPos = 1.2

    if (criticalMetrics.length > 0) {
      slide.addText("Critical Areas Requiring Immediate Attention:", {
        x: 0.5,
        y: yPos,
        w: 9,
        h: 0.4,
        fontSize: 16,
        bold: true,
        color: this.brandColors.danger,
      })

      yPos += 0.5
      criticalMetrics.forEach((metric) => {
        slide.addText(`• ${metric.metric}: Requires immediate improvement to reduce financial risk`, {
          x: 0.7,
          y: yPos,
          w: 8.5,
          h: 0.3,
          fontSize: 12,
          color: this.brandColors.dark,
        })
        yPos += 0.4
      })

      yPos += 0.3
    }

    if (moderateMetrics.length > 0) {
      slide.addText("Areas Requiring Attention:", {
        x: 0.5,
        y: yPos,
        w: 9,
        h: 0.4,
        fontSize: 16,
        bold: true,
        color: this.brandColors.warning,
      })

      yPos += 0.5
      moderateMetrics.slice(0, 5).forEach((metric) => {
        slide.addText(`• ${metric.metric}: Consider improvements to maintain moderate performance`, {
          x: 0.7,
          y: yPos,
          w: 8.5,
          h: 0.3,
          fontSize: 12,
          color: this.brandColors.dark,
        })
        yPos += 0.4
      })

      yPos += 0.3
    }

    if (excellentMetrics.length > 0) {
      slide.addText("Strengths to Maintain:", {
        x: 0.5,
        y: yPos,
        w: 9,
        h: 0.4,
        fontSize: 16,
        bold: true,
        color: this.brandColors.success,
      })

      yPos += 0.5
      excellentMetrics.slice(0, 5).forEach((metric) => {
        slide.addText(`• ${metric.metric}: Continue current practices to maintain excellent performance`, {
          x: 0.7,
          y: yPos,
          w: 8.5,
          h: 0.3,
          fontSize: 12,
          color: this.brandColors.dark,
        })
        yPos += 0.4
      })
    }

    // Overall recommendation
    slide.addText("Overall Assessment:", {
      x: 0.5,
      y: 4.5,
      w: 9,
      h: 0.4,
      fontSize: 16,
      bold: true,
      color: this.brandColors.primary,
    })

    const overallAssessment =
      options.overallScore > 7
        ? "The supplier demonstrates excellent financial health and represents a low-risk partnership opportunity."
        : options.overallScore > 4
          ? "The supplier shows moderate financial health with some areas requiring attention."
          : "The supplier presents significant financial risks that require careful evaluation and monitoring."

    slide.addText(overallAssessment, {
      x: 0.5,
      y: 5,
      w: 9,
      h: 0.5,
      fontSize: 14,
      color: this.brandColors.dark,
    })
  }

  private addConclusionSlide(options: PPTExportOptions): void {
    const slide = this.pptx.addSlide()

    // Header
    slide.addText("Conclusion", {
      x: 0.5,
      y: 0.5,
      w: 9,
      h: 0.6,
      fontSize: 28,
      bold: true,
      color: this.brandColors.dark,
    })

    slide.addText("Financial Analysis Summary", {
      x: 1.5,
      y: 1.8,
      w: 7,
      h: 0.4,
      fontSize: 18,
      bold: true,
      color: this.brandColors.primary,
    })

    const summaryLines = [
      `Supplier: ${options.supplierName}`,
      `Analysis Period: ${options.year}`,
      `Overall Score: ${options.overallScore}/10`,
      `Risk Level: ${options.overallScore > 7 ? "Low" : options.overallScore > 4 ? "Medium" : "High"}`,
      "",
      "This comprehensive analysis provides insights into the supplier's financial stability,",
      "profitability, and operational efficiency to support informed business decisions.",
    ]

    let textYPos = 2.3
    summaryLines.forEach((line) => {
      slide.addText(line, {
        x: 1.5,
        y: textYPos,
        w: 7,
        h: 0.2,
        fontSize: 12,
        color: this.brandColors.dark,
      })
      textYPos += 0.25
    })

    // Footer
    slide.addText("Generated by Financial Analysis System", {
      x: 0.5,
      y: 5,
      w: 9,
      h: 0.3,
      fontSize: 10,
      color: this.brandColors.muted,
      align: "center",
      italic: true,
    })
  }

  public async exportToPPT(options: PPTExportOptions): Promise<void> {
    try {
      // Setup presentation with dynamic import
      await this.setupPresentation()

      // Add all slides
      this.addTitleSlide(options)
      this.addExecutiveSummarySlide(options)
      this.addFinancialMetricsSlide(options)
      this.addSubgradeAnalysisSlide(options)
      this.addRecommendationsSlide(options)
      this.addConclusionSlide(options)

      // Generate and save the presentation
      const fileName = `${options.supplierName}_Financial_Analysis_${options.year}.pptx`
      await this.pptx.writeFile({ fileName })
    } catch (error) {
      console.error("Error generating PowerPoint:", error)
      throw new Error("Failed to generate PowerPoint presentation")
    }
  }
}
