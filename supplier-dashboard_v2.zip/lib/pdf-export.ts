import jsPDF from "jspdf"
import html2canvas from "html2canvas"

export interface ExportOptions {
  supplierName: string
  year: string
  overallScore: number
  profitabilityScore: number
  solvencyScore: number
  liquidityScore: number
  subgradeData: Array<{
    metric: string
    value: string
    subgrade: number
    status: string
    description: string
    impact: string
  }>
  financialMetrics: {
    turnover: string | number
    addedValue: string | number
    ebe: string | number
    netResult: string | number
  }
}

/**
 * PDFExporter - Left-aligned smaller global score badge + radar to the right
 *
 * Layout specifics:
 * - Left badge (smaller) at (leftX, currentY)
 * - Radar centered vertically next to the badge (to the right), with a fixed spacing
 * - All sizes in mm, deterministic and maintainable
 */
export class PDFExporter {
  private pdf: jsPDF
  private pageWidth: number
  private pageHeight: number
  private margin: number
  private currentY: number

  // Design tokens
  private BRAND_RGB = [17, 70, 178] // deep tech blue
  private NEUTRAL800_RGB = [30, 41, 59]
  private NEUTRAL500_RGB = [100, 116, 139]
  private NEUTRAL300_RGB = [209, 213, 219]
  private SUCCESS_RGB = [16, 185, 129]
  private WARN_RGB = [245, 158, 11]
  private DANGER_RGB = [239, 68, 68]
  private CARD_BG = [248, 250, 252]
  private MONO_FONT = "courier"

  constructor() {
    this.pdf = new jsPDF("p", "mm", "a4")
    this.pageWidth = this.pdf.internal.pageSize.getWidth()
    this.pageHeight = this.pdf.internal.pageSize.getHeight()
    this.margin = 16
    this.currentY = this.margin
  }

  private resetPdf() {
    this.pdf = new jsPDF("p", "mm", "a4")
    this.pageWidth = this.pdf.internal.pageSize.getWidth()
    this.pageHeight = this.pdf.internal.pageSize.getHeight()
    this.currentY = this.margin
  }

  private addNewPageIfNeeded(requiredHeight = 20): void {
    if (this.currentY + requiredHeight > this.pageHeight - this.margin) {
      this.pdf.addPage()
      this.currentY = this.margin
    }
  }

  private addHeader(options: ExportOptions) {
    const headerH = 30
    this.pdf.setFillColor(...this.BRAND_RGB)
    this.pdf.rect(0, 0, this.pageWidth, headerH, "F")

    this.pdf.setFontSize(16)
    this.pdf.setFont("helvetica", "bold")
    this.pdf.setTextColor(255, 255, 255)
    this.pdf.text("Supplier Financial Analysis", this.margin, 10 + 6)

    const rightText = `${options.supplierName} • ${options.year}`
    this.pdf.setFontSize(10)
    this.pdf.setFont("helvetica", "normal")
    const tw = this.pdf.getTextWidth(rightText)
    this.pdf.text(rightText, this.pageWidth - this.margin - tw, 10 + 6)

    this.pdf.setDrawColor(...this.NEUTRAL300_RGB)
    this.pdf.setLineWidth(0.3)
    this.pdf.line(this.margin, headerH + 2, this.pageWidth - this.margin, headerH + 2)

    this.currentY = headerH + 8
  }

  private addSectionTitle(title: string, subtitle?: string) {
    this.addNewPageIfNeeded(16)
    this.pdf.setFontSize(12)
    this.pdf.setFont("helvetica", "bold")
    this.pdf.setTextColor(...this.NEUTRAL800_RGB)
    this.pdf.text(title, this.margin, this.currentY)
    if (subtitle) {
      this.pdf.setFontSize(9)
      this.pdf.setFont("helvetica", "normal")
      this.pdf.setTextColor(...this.NEUTRAL500_RGB)
      this.pdf.text(subtitle, this.margin, this.currentY + 6)
      this.currentY += 12
    } else {
      this.currentY += 10
    }
  }

  private addSpacer(h = 6) {
    this.currentY += h
  }

  /* Helpers */
  private sanitizeNumberString(value: string | number) {
    if (typeof value === "number") {
      return new Intl.NumberFormat("fr-FR").format(value)
    }
    if (!value) return ""
    const s = String(value)
    return s.replace(/\//g, "").trim()
  }

  private clampText(text: string, maxChars = 40) {
    if (!text) return ""
    return text.length > maxChars ? text.slice(0, maxChars - 1) + "…" : text
  }

  /* Left-aligned smaller badge for global score
     - leftX, topY specify top-left corner of badge
     - returns width and height used as { w, h }
  */
  private drawLeftGlobalBadge(overall: number, leftX: number, topY: number): { w: number; h: number } {
    // Slightly smaller than previous: more compact square
    const W = 72 // mm total width of badge area
    const H = 40
    const radius = 3

    // background plate (white with subtle border)
    this.pdf.setFillColor(255, 255, 255)
    this.pdf.setDrawColor(...this.NEUTRAL300_RGB)
    this.pdf.roundedRect(leftX, topY, W, H, radius, radius, "S")

    // accent stripe
    this.pdf.setFillColor(...this.BRAND_RGB)
    this.pdf.roundedRect(leftX, topY, W, 8, radius, radius, "F")

    // Title "RATING"
    this.pdf.setFontSize(9)
    this.pdf.setFont("helvetica", "bold")
    this.pdf.setTextColor(255, 255, 255)
    this.pdf.text("RATING", leftX + 8, topY + 6)

    // Subtitle "SCORE GLOBAL" centered under stripe
    this.pdf.setFontSize(8)
    this.pdf.setFont("helvetica", "normal")
    this.pdf.setTextColor(...this.NEUTRAL500_RGB)
    const subtitle = "SCORE GLOBAL"
    const subtitleTw = this.pdf.getTextWidth(subtitle)
    this.pdf.text(subtitle, leftX + W / 2 - subtitleTw / 2, topY + 16)

    // Big score left-aligned inside badge (but visually dominant)
    const scoreStr = `${overall}`
    const bigFontSize = 34 // somewhat large to attract attention
    this.pdf.setFontSize(bigFontSize)
    this.pdf.setFont("helvetica", "bold")
    this.pdf.setTextColor(...this.NEUTRAL800_RGB)
    const scoreTw = this.pdf.getTextWidth(scoreStr)
    // place score left-ish leaving room for /10 at right
    const scoreX = leftX + 10
    const scoreY = topY + 32
    this.pdf.text(scoreStr, scoreX, scoreY)

    // small /10 aligned to the baseline of big number
    this.pdf.setFontSize(10)
    this.pdf.setFont("helvetica", "normal")
    const s10 = "/10"
    const s10X = scoreX + scoreTw + 4
    const s10Y = scoreY - 6
    this.pdf.text(s10, s10X, s10Y)

    // Optionally draw a thin divider and risk level text on right side of badge (small)
    const riskText = overall >= 7 ? "Low Risk" : overall >= 5 ? "Medium Risk" : "High Risk"
    this.pdf.setFontSize(8)
    this.pdf.setFont("helvetica", "normal")
    this.pdf.setTextColor(...this.NEUTRAL500_RGB)
    const rtX = leftX + W - 6 - this.pdf.getTextWidth(riskText)
    this.pdf.text(riskText, rtX, topY + 16)

    return { w: W, h: H }
  }

  /* Radar chart (3 axes) - same safe implementation as before
     - centerX, centerY, maxRadius provided
  */
  private drawRadarChart(values: { profitability: number; solvency: number; liquidity: number }, centerX: number, centerY: number, maxRadius = 36) {
    const angles = [-Math.PI / 2, (150 * Math.PI) / 180, (-30 * Math.PI) / 180]
    const labels = ["Profitability", "Solvency", "Liquidity"]
    const scores = [values.profitability ?? 0, values.solvency ?? 0, values.liquidity ?? 0]

        // ===== Grid rings: 10 concentric rings (levels 1..10) + small tick marks on axes =====
    // Draw 10 faint concentric circles for levels 1..10 (1/10 .. 10/10 of maxRadius)
    this.pdf.setLineWidth(0.2)
    this.pdf.setDrawColor(...this.NEUTRAL300_RGB)
    const levels = 10
    for (let lvl = 1; lvl <= levels; lvl++) {
      const r = (lvl / levels) * maxRadius
      this.pdf.circle(centerX, centerY, r, "D")
    }

    // Draw radial axis tick marks at each level for each axis (small perpendicular ticks)
    // tick length in mm
    const tickLen = 1.5
    this.pdf.setLineWidth(0.4)
    this.pdf.setDrawColor(...this.NEUTRAL300_RGB)
    for (let ai = 0; ai < angles.length; ai++) {
      const ang = angles[ai]
      for (let lvl = 1; lvl <= levels; lvl++) {
        const r = (lvl / levels) * maxRadius
        // point on axis
        const px = centerX + Math.cos(ang) * r
        const py = centerY + Math.sin(ang) * r
        // compute perpendicular direction
        const perpAng = ang + Math.PI / 2
        const tx1 = px + Math.cos(perpAng) * (tickLen / 2)
        const ty1 = py + Math.sin(perpAng) * (tickLen / 2)
        const tx2 = px - Math.cos(perpAng) * (tickLen / 2)
        const ty2 = py - Math.sin(perpAng) * (tickLen / 2)
        this.pdf.line(tx1, ty1, tx2, ty2)
      }
    }

    // Optionally show numeric labels for some levels (every 2 levels to avoid clutter)
    this.pdf.setFontSize(7)
    this.pdf.setTextColor(...this.NEUTRAL500_RGB)
    for (let lvl = 2; lvl <= levels; lvl += 2) {
      const r = (lvl / levels) * maxRadius
      // place label at top (angle -90°)
      const lx = centerX + Math.cos(-Math.PI / 2) * r
      const ly = centerY + Math.sin(-Math.PI / 2) * r - 2 // slight offset upward
      this.pdf.text(String(lvl), lx - this.pdf.getTextWidth(String(lvl)) / 2, ly)
    }

    // ===== Axes =====
    this.pdf.setLineWidth(0.6)
    this.pdf.setDrawColor(...this.NEUTRAL300_RGB)
    for (let i = 0; i < 3; i++) {
      const ang = angles[i]
      const x2 = centerX + Math.cos(ang) * maxRadius
      const y2 = centerY + Math.sin(ang) * maxRadius
      this.pdf.line(centerX, centerY, x2, y2)
    }


    // points
    const pts: { x: number; y: number }[] = []
    for (let i = 0; i < 3; i++) {
      const val = Math.max(0, Math.min(10, scores[i]))
      const length = (val / 10) * maxRadius
      const x = centerX + Math.cos(angles[i]) * length
      const y = centerY + Math.sin(angles[i]) * length
      pts.push({ x, y })
    }

    // fill triangles center->a->b
    this.pdf.setFillColor(230, 240, 255)
    for (let i = 0; i < pts.length; i++) {
      const a = pts[i]
      const b = pts[(i + 1) % pts.length]
      ;(this.pdf as any).triangle(centerX, centerY, a.x, a.y, b.x, b.y, "F")
    }

    // outline polygon
    this.pdf.setDrawColor(...this.BRAND_RGB)
    this.pdf.setLineWidth(0.9)
    for (let i = 0; i < pts.length; i++) {
      const a = pts[i]
      const b = pts[(i + 1) % pts.length]
      this.pdf.line(a.x, a.y, b.x, b.y)
    }

    // labels
    this.pdf.setFontSize(8)
    this.pdf.setFont("helvetica", "normal")
    this.pdf.setTextColor(...this.NEUTRAL500_RGB)
    for (let i = 0; i < 3; i++) {
      const ang = angles[i]
      const lx = centerX + Math.cos(ang) * (maxRadius + 10)
      const ly = centerY + Math.sin(ang) * (maxRadius + 10)
      const txt = `${labels[i]} (${scores[i].toFixed(1)}/10)`
      const tw = this.pdf.getTextWidth(txt)
      let tx = lx
      if (Math.cos(ang) < -0.3) tx = lx - tw
      if (Math.cos(ang) > 0.3) tx = lx
      this.pdf.text(txt, tx, ly + 3)
    }
  }

  /* Simple financial metrics table */
  private addFinancialMetricsTable(metrics: ExportOptions["financialMetrics"]) {
    const colWidths = [60, 60]
    const rowH = 8
    this.addNewPageIfNeeded(rowH * 4 + 10)

    const labels = ["Turnover", "Added Value", "EBE", "Net Result"]
    const valuesRaw = [metrics.turnover, metrics.addedValue, metrics.ebe, metrics.netResult]
    const tableX = this.margin
    let y = this.currentY

    this.pdf.setFontSize(9)
    for (let i = 0; i < labels.length; i++) {
      this.pdf.setFillColor(...this.CARD_BG)
      this.pdf.rect(tableX, y, colWidths[0] + colWidths[1], rowH, "F")
      this.pdf.setFont("helvetica", "bold")
      this.pdf.setTextColor(...this.NEUTRAL800_RGB)
      this.pdf.text(labels[i], tableX + 4, y + 6)

      const raw = valuesRaw[i]
      const formatted = this.sanitizeNumberString(raw)
      this.pdf.setFont(this.MONO_FONT as any, "normal")
      this.pdf.setFontSize(9)
      this.pdf.setTextColor(...this.NEUTRAL500_RGB)
      const valX = tableX + colWidths[0] + 6
      this.pdf.text(formatted, valX, y + 6)
      y += rowH
    }

    this.currentY = y + 8
  }

  /* Subgrade table */
  private addSubgradeTable(subgradeData: ExportOptions["subgradeData"]) {
    const headers = ["Metric", "Value", "Score", "Status"]
    const colWidths = [78, 35, 25, 30]
    const rowH = 9
    this.addNewPageIfNeeded(rowH * (subgradeData.length + 4))

    this.pdf.setFillColor(246, 249, 255)
    this.pdf.rect(this.margin, this.currentY, this.pageWidth - 2 * this.margin, rowH, "F")
    this.pdf.setFontSize(9)
    this.pdf.setFont("helvetica", "bold")
    let x = this.margin + 2
    headers.forEach((h, i) => {
      this.pdf.setTextColor(...this.NEUTRAL800_RGB)
      this.pdf.text(h, x, this.currentY + 6)
      x += colWidths[i]
    })
    this.currentY += rowH

    this.pdf.setFont("helvetica", "normal")
    this.pdf.setFontSize(9)
    subgradeData.forEach((r, idx) => {
      this.addNewPageIfNeeded(rowH)
      this.pdf.setFillColor(idx % 2 === 0 ? 255 : 250)
      this.pdf.rect(this.margin, this.currentY, this.pageWidth - 2 * this.margin, rowH, "F")

      let cx = this.margin + 2
      this.pdf.setTextColor(...this.NEUTRAL800_RGB)
      this.pdf.text(this.clampText(r.metric, 36), cx, this.currentY + 6)
      cx += colWidths[0]
      this.pdf.setFont(this.MONO_FONT as any, "normal")
      this.pdf.text(String(r.value), cx, this.currentY + 6)
      cx += colWidths[1]
      this.pdf.setFont("helvetica", "normal")
      this.pdf.text(`${r.subgrade.toFixed(1)}/10`, cx, this.currentY + 6)
      cx += colWidths[2]

      const status = r.status.toLowerCase()
      let color = this.DANGER_RGB
      let label = "Critical"
      if (status === "excellent" || status === "yes") {
        color = this.SUCCESS_RGB
        label = "Excellent"
      } else if (status === "neutre" || status === "moderate" || status === "neutral") {
        color = this.WARN_RGB
        label = "Moderate"
      }
      const badgeW = this.pdf.getTextWidth(label) + 6
      const bx = cx + 6
      const by = this.currentY + 2
      this.pdf.setFillColor(...color)
      this.pdf.roundedRect(bx, by, badgeW, 6, 1.5, 1.5, "F")
      this.pdf.setFontSize(8)
      this.pdf.setTextColor(255, 255, 255)
      this.pdf.text(label, bx + 3, by + 4)

      this.currentY += rowH
    })

    this.addSpacer(6)
  }

  public async exportToPDF(options: ExportOptions): Promise<void> {
    try {
      this.resetPdf()
      this.addHeader(options)

      // Section title
      this.addSectionTitle("Financial Health Overview", "Global rating (left) + radar (right)")

      // Layout: left badge + radar to the right
      const leftX = this.margin
      const topY = this.currentY

      // draw left badge (smaller) and get its used size
      const badge = this.drawLeftGlobalBadge(options.overallScore, leftX, topY)

      // compute radar position to the right of badge with spacing
      const spacing = 12 // mm space between badge and radar
      const radarCenterX = leftX + badge.w + spacing + 36 // 36 is half radar width assumption
      const radarCenterY = topY + badge.h / 2 // align vertically centered with badge

      // make sure radar doesn't overflow right margin; if so, shift left a bit
      const maxRadarRadius = 36
      const radarRightEdge = radarCenterX + maxRadarRadius + 10
      if (radarRightEdge > this.pageWidth - this.margin) {
        // shift left so right edge fits
        const overflow = radarRightEdge - (this.pageWidth - this.margin)
        // move radar left by overflow
        // but keep at least margin from left
        const newRadarCenterX = Math.max(leftX + badge.w + spacing + maxRadarRadius, radarCenterX - overflow)
        // update radarCenterX
        // @ts-ignore local reassign
        radarCenterX = newRadarCenterX
      }

      // draw radar
      this.drawRadarChart(
        {
          profitability: options.profitabilityScore,
          solvency: options.solvencyScore,
          liquidity: options.liquidityScore,
        },
        radarCenterX,
        radarCenterY,
        maxRadarRadius,
      )

      // advance currentY below the badge and radar (whichever lower)
      const usedBottom = Math.max(topY + badge.h, radarCenterY + maxRadarRadius) // mm
      this.currentY = usedBottom + 12

      // Key financial metrics table
      this.addSectionTitle("Key Financial Metrics")
      this.addFinancialMetricsTable(options.financialMetrics)

      // Subgrade breakdown
      this.addSectionTitle("Subgrade Breakdown", "All measured metrics with status")
      this.addSubgradeTable(options.subgradeData)

      // Metric details pages
      this.addSectionTitle("Metric Details", "Descriptions & impacts")
      options.subgradeData.forEach((m) => {
        this.addNewPageIfNeeded(60)
        this.pdf.setFontSize(11)
        this.pdf.setFont("helvetica", "bold")
        this.pdf.setTextColor(...this.NEUTRAL800_RGB)
        this.pdf.text(`${m.metric} — ${m.value}`, this.margin, this.currentY)
        this.currentY += 7

        const st = m.status.toLowerCase()
        const stColor = st === "excellent" ? this.SUCCESS_RGB : st === "neutre" ? this.WARN_RGB : this.DANGER_RGB
        this.pdf.setFillColor(...stColor)
        this.pdf.roundedRect(this.margin, this.currentY, 24, 7, 2, 2, "F")
        this.pdf.setFontSize(8)
        this.pdf.setTextColor(255, 255, 255)
        this.pdf.text(st === "excellent" ? "EXCELLENT" : st === "neutre" ? "NEUTRE" : "CRITICAL", this.margin + 3, this.currentY + 5)
        this.currentY += 10

        this.pdf.setFontSize(10)
        this.pdf.setFont("helvetica", "normal")
        this.pdf.setTextColor(...this.NEUTRAL500_RGB)
        const descLines = this.pdf.splitTextToSize(`Description: ${m.description}`, this.pageWidth - 2 * this.margin)
        this.pdf.text(descLines, this.margin, this.currentY)
        this.currentY += descLines.length * 5 + 4

        const impactLines = this.pdf.splitTextToSize(`Impact: ${m.impact}`, this.pageWidth - 2 * this.margin)
        this.pdf.setFontSize(9)
        this.pdf.setTextColor(...this.NEUTRAL500_RGB)
        this.pdf.text(impactLines, this.margin, this.currentY)
        this.currentY += impactLines.length * 5 + 8
      })

      // Recommendations
      this.addSectionTitle("Recommendations")
      const criticalIssues = options.subgradeData.filter((s) => s.status.toLowerCase() === "critical" || s.status.toLowerCase() === "no")
      if (criticalIssues.length > 0) {
        this.pdf.setFontSize(10)
        this.pdf.setTextColor(...this.DANGER_RGB)
        this.pdf.setFont("helvetica", "bold")
        this.pdf.text("Immediate priorities", this.margin, this.currentY)
        this.currentY += 6
        this.pdf.setFont("helvetica", "normal")
        this.pdf.setFontSize(9)
        this.pdf.setTextColor(...this.NEUTRAL500_RGB)
        criticalIssues.forEach((s) => {
          const lines = this.pdf.splitTextToSize(`• ${s.metric}: urgent action recommended (cash, renegotiate, short-term financing).`, this.pageWidth - 2 * this.margin)
          this.pdf.text(lines, this.margin + 4, this.currentY)
          this.currentY += lines.length * 5
        })
      } else {
        this.pdf.setFontSize(10)
        this.pdf.setTextColor(...this.SUCCESS_RGB)
        this.pdf.setFont("helvetica", "normal")
        this.pdf.text("No critical actions detected. Maintain current optimizations.", this.margin, this.currentY)
        this.currentY += 10
      }

      // Footer
      const pageCount = this.pdf.getNumberOfPages()
      const genDate = new Date().toLocaleString()
      for (let i = 1; i <= pageCount; i++) {
        this.pdf.setPage(i)
        this.pdf.setFontSize(8)
        this.pdf.setTextColor(...this.NEUTRAL500_RGB)
        this.pdf.text(`Generated: ${genDate}`, this.margin, this.pageHeight - 10)
        const pageTxt = `Page ${i} / ${pageCount}`
        const tw = this.pdf.getTextWidth(pageTxt)
        this.pdf.text(pageTxt, this.pageWidth - this.margin - tw, this.pageHeight - 10)
      }

      const safeSupplier = options.supplierName.replace(/[^a-z0-9_\-]/gi, "_").slice(0, 40)
      this.pdf.save(`${safeSupplier}_Financial_Analysis_${options.year}.pdf`)
    } catch (err) {
      console.error("PDF export error (left badge + radar):", err)
      throw new Error("Failed to generate PDF")
    }
  }

  public async exportDashboardToPDF(elementId: string, filename: string): Promise<void> {
    try {
      const element = document.getElementById(elementId)
      if (!element) throw new Error("Dashboard element not found")

      const clone = element.cloneNode(true) as HTMLElement
      clone.style.position = "absolute"
      clone.style.left = "-9999px"
      clone.style.boxSizing = "border-box"
      clone.style.width = `${element.scrollWidth}px`
      document.body.appendChild(clone)

      const canvas = await html2canvas(clone, {
        scale: 2,
        useCORS: true,
        allowTaint: true,
        backgroundColor: "#ffffff",
        width: clone.scrollWidth,
        height: clone.scrollHeight,
        scrollX: 0,
        scrollY: -window.scrollY,
      })

      document.body.removeChild(clone)

      const imgData = canvas.toDataURL("image/png")
      const pdf = new jsPDF("p", "mm", "a4")
      const pdfW = pdf.internal.pageSize.getWidth()
      const pdfH = pdf.internal.pageSize.getHeight()
      const margin = 10
      const imgW = pdfW - margin * 2
      const imgH = (canvas.height * imgW) / canvas.width

      let pos = margin
      pdf.addImage(imgData, "PNG", margin, pos, imgW, imgH)
      let hLeft = imgH - (pdfH - margin * 2)
      while (hLeft > 0) {
        pos = hLeft - imgH + margin
        pdf.addPage()
        pdf.addImage(imgData, "PNG", margin, pos, imgW, imgH)
        hLeft -= pdfH - margin * 2
      }

      pdf.save(filename)
    } catch (err) {
      console.error("Dashboard export error (left badge + radar):", err)
      throw new Error("Failed to export dashboard")
    }
  }
}
