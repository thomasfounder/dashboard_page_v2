"use client"

import { useState } from "react"
import {
  AlertTriangle,
  ArrowDown,
  ArrowUp,
  CheckCircle,
  Download,
  XCircle,
  Minus,
  TrendingUp,
  Activity,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"

export default function SupplierDashboard() {
  const [activeTab, setActiveTab] = useState("profitability")

  const subgradeData = [
    {
      metric: "Financial Independence",
      value: "23.8%",
      status: "critical",
      description:
        "Measures the proportion of assets financed by equity rather than debt. Low independence indicates high reliance on external financing.",
      impact: "High Risk - Heavy dependence on external financing increases vulnerability to market changes.",
    },
    {
      metric: "Repayment Capacity",
      value: "8.2 years",
      status: "warning",
      description:
        "Number of years needed to repay total debt using current cash flow. Longer periods indicate weaker debt servicing ability.",
      impact: "Medium Risk - Extended repayment period suggests potential cash flow constraints.",
    },
    {
      metric: "ROE (Return On Equity)",
      value: "12.4%",
      status: "warning",
      description:
        "Measures profitability relative to shareholders' equity. Indicates how effectively the company generates profits from equity investments.",
      impact: "Below Average - Moderate returns on equity investment, room for improvement.",
    },
    {
      metric: "The Margin",
      value: "9.7%",
      status: "warning",
      description:
        "Net profit margin showing percentage of revenue retained as profit after all expenses. Key indicator of operational efficiency.",
      impact: "Below Industry Standard - Profit margins are acceptable but below optimal levels.",
    },
    {
      metric: "Debt Ratio",
      value: "76.2%",
      status: "critical",
      description:
        "Percentage of total assets financed by debt. High ratios indicate greater financial risk and leverage.",
      impact: "Critical Risk - Excessive debt levels threaten financial stability and flexibility.",
    },
    {
      metric: "EBE / CA",
      value: "18.0%",
      status: "warning",
      description:
        "Earnings Before Interest (EBE) as percentage of Total Assets (CA). Measures operational efficiency and asset utilization.",
      impact: "Moderate Performance - Asset utilization is reasonable but could be optimized.",
    },
    {
      metric: "Immediate Liquidity",
      value: "45 days",
      status: "warning",
      description:
        "Days of cash and equivalents available to cover immediate obligations. Measures short-term financial flexibility.",
      impact: "Adequate - Sufficient immediate liquidity but higher than optimal levels.",
    },
    {
      metric: "Customer Payment Time",
      value: "28 days",
      status: "good",
      description:
        "Average days to collect receivables from customers. Shorter periods indicate efficient collection processes.",
      impact: "Excellent - Fast customer payment collection enhances cash flow management.",
    },
    {
      metric: "Supplier Payment Time",
      value: "32 days",
      status: "good",
      description:
        "Average days to pay suppliers. Balanced payment timing maintains good supplier relationships while optimizing cash flow.",
      impact: "Optimal - Well-balanced payment schedule maintains supplier relationships.",
    },
    {
      metric: "General Liquidity",
      value: "2.4",
      status: "good",
      description:
        "Current ratio measuring ability to pay short-term obligations. Higher ratios indicate better short-term financial health.",
      impact: "Strong - Excellent ability to meet short-term obligations.",
    },
  ]

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "good":
        return <CheckCircle className="h-5 w-5 text-green-500" />
      case "warning":
        return <AlertTriangle className="h-5 w-5 text-amber-500" />
      case "critical":
        return <XCircle className="h-5 w-5 text-destructive" />
      default:
        return <Minus className="h-5 w-5 text-muted-foreground" />
    }
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "good":
        return (
          <Badge variant="outline" className="text-green-500 border-green-500">
            Excellent
          </Badge>
        )
      case "warning":
        return (
          <Badge variant="outline" className="text-amber-500 border-amber-500">
            Warning
          </Badge>
        )
      case "critical":
        return <Badge variant="destructive">Critical</Badge>
      default:
        return <Badge variant="outline">Neutral</Badge>
    }
  }

  const renderTabContent = () => {
    switch (activeTab) {
      case "profitability":
        return (
          <div className="space-y-4">
            <div className="flex items-center justify-between p-3 rounded-lg bg-amber-50 border border-amber-200">
              <div className="flex items-center gap-3">
                <AlertTriangle className="h-6 w-6 text-amber-500" />
                <div>
                  <p className="font-medium">Moderate Profitability</p>
                  <p className="text-sm text-muted-foreground">Below industry standards</p>
                </div>
              </div>
              <Badge variant="outline" className="text-amber-500 border-amber-500">
                5/10
              </Badge>
            </div>
            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-sm">Net Margin</span>
                <span className="font-medium">9.7%</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm">ROE</span>
                <span className="font-medium">12.4%</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm">EBE/CA</span>
                <span className="font-medium">18.0%</span>
              </div>
            </div>
          </div>
        )
      case "solvency":
        return (
          <div className="space-y-4">
            <div className="flex items-center justify-between p-3 rounded-lg bg-red-50 border border-red-200">
              <div className="flex items-center gap-3">
                <XCircle className="h-6 w-6 text-red-500" />
                <div>
                  <p className="font-medium">Critical Solvency Issues</p>
                  <p className="text-sm text-muted-foreground">High debt levels</p>
                </div>
              </div>
              <Badge variant="destructive">0/10</Badge>
            </div>
            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-sm">Financial Independence</span>
                <span className="font-medium">23.8%</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm">Repayment Capacity</span>
                <span className="font-medium">8.2 years</span>
              </div>
            </div>
          </div>
        )
      case "liquidity":
        return (
          <div className="space-y-4">
            <div className="flex items-center justify-between p-3 rounded-lg bg-green-50 border border-green-200">
              <div className="flex items-center gap-3">
                <CheckCircle className="h-6 w-6 text-green-500" />
                <div>
                  <p className="font-medium">Excellent Liquidity</p>
                  <p className="text-sm text-muted-foreground">Strong short-term position</p>
                </div>
              </div>
              <Badge variant="outline" className="text-green-500 border-green-500">
                10/10
              </Badge>
            </div>
            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-sm">Immediate Liquidity</span>
                <span className="font-medium">45 days</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm">Customer Payment Time</span>
                <span className="font-medium">28 days</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm">General Liquidity</span>
                <span className="font-medium">2.4</span>
              </div>
            </div>
          </div>
        )
      default:
        return null
    }
  }

  return (
    <div className="flex min-h-screen flex-col bg-muted/40">
      <header className="sticky top-0 z-10 flex h-16 items-center gap-4 border-b bg-background px-6">
        <h1 className="text-xl font-semibold">Supplier Financial Analysis</h1>
        <div className="ml-auto flex items-center gap-4">
          <div className="w-[220px] border rounded-md px-3 py-2 text-sm">Supplier_name</div>
          <div className="w-[120px] border rounded-md px-3 py-2 text-sm">2023</div>
          <Button variant="outline" size="icon">
            <Download className="h-4 w-4" />
          </Button>
        </div>
      </header>
      <main className="flex-1 p-6 grid gap-6">
        {/* Executive Summary Section */}
        <Card className="border-l-4 border-l-amber-500">
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="text-2xl flex items-center gap-2">
                  <Activity className="h-6 w-6 text-amber-500" />
                  Executive Summary
                </CardTitle>
                <CardDescription className="text-base mt-2">
                  Overall financial health assessment for supplier evaluation
                </CardDescription>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="grid gap-6 md:grid-cols-4">
              {/* Overall Rating */}
              <div className="flex flex-col items-center justify-center space-y-4">
                <div className="relative flex h-32 w-32 items-center justify-center rounded-full">
                  <svg className="h-32 w-32" viewBox="0 0 100 100">
                    <circle className="stroke-muted" cx="50" cy="50" r="45" strokeWidth="8" fill="none" />
                    <circle
                      className="stroke-amber-500"
                      cx="50"
                      cy="50"
                      r="45"
                      strokeWidth="8"
                      fill="none"
                      strokeDasharray="282.7"
                      strokeDashoffset="93.3"
                      transform="rotate(-90 50 50)"
                    />
                  </svg>
                  <div className="absolute flex flex-col items-center justify-center">
                    <span className="text-3xl font-bold">6.7</span>
                    <span className="text-xs text-muted-foreground">/10</span>
                  </div>
                </div>
                <div className="text-center">
                  <h3 className="font-semibold">Overall Rating</h3>
                  <p className="text-sm text-muted-foreground">Medium Risk</p>
                </div>
              </div>

              {/* Key Metrics Grid */}
              <div className="md:col-span-2 grid gap-4">
                <div className="grid grid-cols-3 gap-4">
                  {/* Solvency */}
                  <div className="text-center p-4 rounded-lg border bg-red-50 border-red-200">
                    <div className="flex items-center justify-center mb-2">
                      <XCircle className="h-8 w-8 text-red-500" />
                    </div>
                    <h4 className="font-semibold text-sm mb-1">Solvency</h4>
                    <div className="text-2xl font-bold text-red-500">0/10</div>
                    <Progress value={0} className="h-2 mt-2" />
                    <p className="text-xs text-muted-foreground mt-1">Critical</p>
                  </div>

                  {/* Profitability */}
                  <div className="text-center p-4 rounded-lg border bg-amber-50 border-amber-200">
                    <div className="flex items-center justify-center mb-2">
                      <AlertTriangle className="h-8 w-8 text-amber-500" />
                    </div>
                    <h4 className="font-semibold text-sm mb-1">Profitability</h4>
                    <div className="text-2xl font-bold text-amber-500">5/10</div>
                    <Progress value={50} className="h-2 mt-2" />
                    <p className="text-xs text-muted-foreground mt-1">Moderate</p>
                  </div>

                  {/* Liquidity */}
                  <div className="text-center p-4 rounded-lg border bg-green-50 border-green-200">
                    <div className="flex items-center justify-center mb-2">
                      <CheckCircle className="h-8 w-8 text-green-500" />
                    </div>
                    <h4 className="font-semibold text-sm mb-1">Liquidity</h4>
                    <div className="text-2xl font-bold text-green-500">10/10</div>
                    <Progress value={100} className="h-2 mt-2" />
                    <p className="text-xs text-muted-foreground mt-1">Excellent</p>
                  </div>
                </div>

                {/* Profitability Assessment */}
                <div className="p-4 rounded-lg bg-amber-50 border border-amber-200">
                  <div className="flex items-center gap-2 mb-2">
                    <AlertTriangle className="h-5 w-5 text-amber-600" />
                    <h4 className="font-semibold text-amber-800">MODERATE PROFITABILITY</h4>
                  </div>
                  <p className="text-sm text-amber-700">
                    The supplier demonstrates moderate profitability with several areas of concern that require
                    monitoring.
                  </p>
                </div>
              </div>

              {/* Risk Summary */}
              <div className="space-y-4 border-l-4 border-l-slate-300 pl-4 bg-slate-50/50 rounded-r-lg py-2">
                <h4 className="font-semibold text-center text-slate-700">Risk Summary</h4>
                <div className="space-y-3">
                  <div className="flex items-center justify-between p-2 rounded border bg-red-50 border-red-200">
                    <span className="text-sm font-medium">Critical Issues</span>
                    <Badge variant="destructive" className="text-xs">
                      2
                    </Badge>
                  </div>
                  <div className="flex items-center justify-between p-2 rounded border bg-amber-50 border-amber-200">
                    <span className="text-sm font-medium">Warning Areas</span>
                    <Badge variant="outline" className="text-amber-500 border-amber-500 text-xs">
                      5
                    </Badge>
                  </div>
                  <div className="flex items-center justify-between p-2 rounded border bg-green-50 border-green-200">
                    <span className="text-sm font-medium">Positive Indicators</span>
                    <Badge variant="outline" className="text-green-500 border-green-500 text-xs">
                      3
                    </Badge>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Financial Metrics Section */}
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <TrendingUp className="h-5 w-5 text-green-500" />
                Key Financial Metrics
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <p className="text-sm text-muted-foreground">Turnover</p>
                    <p className="text-2xl font-bold">€728,845</p>
                    <div className="flex items-center text-sm text-green-500">
                      <ArrowUp className="mr-1 h-4 w-4" />
                      <span>+5.2% YoY</span>
                    </div>
                  </div>
                  <div className="space-y-1">
                    <p className="text-sm text-muted-foreground">Added Value</p>
                    <p className="text-2xl font-bold">€324,553</p>
                    <div className="flex items-center text-sm text-green-500">
                      <ArrowUp className="mr-1 h-4 w-4" />
                      <span>+3.8% YoY</span>
                    </div>
                  </div>
                </div>
                <Separator />
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <p className="text-sm text-muted-foreground">EBE</p>
                    <p className="text-2xl font-bold">€131,201</p>
                    <div className="flex items-center text-sm text-red-500">
                      <ArrowDown className="mr-1 h-4 w-4" />
                      <span>-2.1% YoY</span>
                    </div>
                  </div>
                  <div className="space-y-1">
                    <p className="text-sm text-muted-foreground">Net Result</p>
                    <p className="text-2xl font-bold">€70,712</p>
                    <div className="flex items-center text-sm text-red-500">
                      <ArrowDown className="mr-1 h-4 w-4" />
                      <span>-4.3% YoY</span>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle>Financial Analysis</CardTitle>
              <div className="flex border rounded-md mt-2 overflow-hidden">
                <button
                  onClick={() => setActiveTab("profitability")}
                  className={`flex-1 text-center py-2 px-3 font-medium text-sm transition-colors ${
                    activeTab === "profitability" ? "bg-primary text-primary-foreground" : "hover:bg-muted/50"
                  }`}
                >
                  Profitability
                </button>
                <button
                  onClick={() => setActiveTab("solvency")}
                  className={`flex-1 text-center py-2 px-3 font-medium text-sm transition-colors ${
                    activeTab === "solvency" ? "bg-primary text-primary-foreground" : "hover:bg-muted/50"
                  }`}
                >
                  Solvency
                </button>
                <button
                  onClick={() => setActiveTab("liquidity")}
                  className={`flex-1 text-center py-2 px-3 font-medium text-sm transition-colors ${
                    activeTab === "liquidity" ? "bg-primary text-primary-foreground" : "hover:bg-muted/50"
                  }`}
                >
                  Liquidity
                </button>
              </div>
            </CardHeader>
            <CardContent>{renderTabContent()}</CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <AlertTriangle className="h-5 w-5 text-amber-500" />
                Risk Factors
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex items-center justify-between rounded-lg border p-3 bg-red-50">
                  <div className="flex items-center gap-3">
                    <XCircle className="h-5 w-5 text-destructive" />
                    <span className="font-medium">High Debt Level</span>
                  </div>
                  <Badge variant="destructive">Critical</Badge>
                </div>
                <div className="flex items-center justify-between rounded-lg border p-3 bg-amber-50">
                  <div className="flex items-center gap-3">
                    <AlertTriangle className="h-5 w-5 text-amber-500" />
                    <span className="font-medium">Declining Net Result</span>
                  </div>
                  <Badge variant="outline" className="text-amber-500 border-amber-500">
                    Warning
                  </Badge>
                </div>
                <div className="flex items-center justify-between rounded-lg border p-3 bg-green-50">
                  <div className="flex items-center gap-3">
                    <CheckCircle className="h-5 w-5 text-green-500" />
                    <span className="font-medium">Strong Cash Position</span>
                  </div>
                  <Badge variant="outline" className="text-green-500 border-green-500">
                    Positive
                  </Badge>
                </div>
                <div className="flex items-center justify-between rounded-lg border p-3 bg-green-50">
                  <div className="flex items-center gap-3">
                    <CheckCircle className="h-5 w-5 text-green-500" />
                    <span className="font-medium">Prompt Payment History</span>
                  </div>
                  <Badge variant="outline" className="text-green-500 border-green-500">
                    Positive
                  </Badge>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Detailed Analysis Section */}
        <Card>
          <CardHeader>
            <CardTitle className="text-2xl flex items-center gap-2">
              <Activity className="h-6 w-6" />
              Comprehensive Subgrade Analysis
            </CardTitle>
            <CardDescription className="text-base">
              Detailed evaluation of key financial metrics to assess supplier profitability and financial health
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow className="bg-muted/50">
                    <TableHead className="w-[200px] font-semibold">Financial Metric</TableHead>
                    <TableHead className="text-center font-semibold">Current Value</TableHead>
                    <TableHead className="text-center font-semibold">Status</TableHead>
                    <TableHead className="w-[300px] font-semibold">Description & Impact</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {subgradeData.map((item, index) => (
                    <TableRow key={index} className="hover:bg-muted/30 transition-colors">
                      <TableCell className="font-medium">
                        <div className="flex items-center gap-2">
                          {getStatusIcon(item.status)}
                          <span>{item.metric}</span>
                        </div>
                      </TableCell>
                      <TableCell className="text-center font-mono font-semibold text-base">{item.value}</TableCell>
                      <TableCell className="text-center">{getStatusBadge(item.status)}</TableCell>
                      <TableCell>
                        <div className="space-y-2">
                          <p className="text-sm leading-relaxed">{item.description}</p>
                          <p className="text-xs text-muted-foreground font-medium bg-muted/30 p-2 rounded">
                            {item.impact}
                          </p>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      </main>
    </div>
  )
}
